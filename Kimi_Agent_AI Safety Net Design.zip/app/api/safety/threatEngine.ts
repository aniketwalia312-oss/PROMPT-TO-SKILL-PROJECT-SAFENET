import type { LatLng } from "./geo";

export type RiskLevel = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export interface ThreatContext {
  routeDeviationM?: number; // distance off planned route
  inHighRiskZone?: { label: string; riskScore: number } | null;
  checkInStatus?: "none" | "pending" | "answered" | "missed";
  journeyOvertimeMin?: number;
  prolongedStopMin?: number;
  explicitSos?: boolean;
  userReportedDistress?: boolean; // guardian NLP flagged distress
  voiceDistressConfidence?: number; // 0-1 from tone analysis
  hour?: number;
}

export interface ThreatAssessment {
  riskLevel: RiskLevel;
  riskScore: number; // 0-100, 100 = safest
  confidence: number; // 0-1
  reasons: string[];
  recommendedAction: string;
  requiresVerification: boolean;
  signals: Record<string, number>;
}

// ThreatAssessmentEngine — contextual signal fusion.
// A single weak signal never constitutes an emergency; risk rises only when
// independent signals corroborate each other. Explicit SOS bypasses fusion.
export class ThreatAssessmentEngine {
  static assess(ctx: ThreatContext): ThreatAssessment {
    // Explicit SOS → immediately critical, user's configured workflow activates
    if (ctx.explicitSos) {
      return {
        riskLevel: "CRITICAL",
        riskScore: 0,
        confidence: 1,
        reasons: ["Explicit SOS activated by user"],
        recommendedAction: "Activate configured emergency workflow immediately",
        requiresVerification: false,
        signals: { explicitSos: 100 },
      };
    }

    const signals: Record<string, number> = {};
    const reasons: string[] = [];
    let danger = 0; // 0-100 danger accumulation

    if (ctx.routeDeviationM !== undefined && ctx.routeDeviationM > 120) {
      const w = Math.min(25, 8 + ctx.routeDeviationM / 60);
      signals.routeDeviation = Math.round(w);
      danger += w;
      reasons.push(`Significant route deviation (${Math.round(ctx.routeDeviationM)}m off planned route)`);
    }

    if (ctx.inHighRiskZone && ctx.inHighRiskZone.riskScore >= 60) {
      const w = 15 + ctx.inHighRiskZone.riskScore * 0.25;
      signals.highRiskZone = Math.round(w);
      danger += w;
      reasons.push(`Entered high-risk zone: ${ctx.inHighRiskZone.label} (risk ${ctx.inHighRiskZone.riskScore}/100)`);
    }

    if (ctx.checkInStatus === "missed") {
      signals.missedCheckIn = 22;
      danger += 22;
      reasons.push("Safety check went unanswered");
    } else if (ctx.checkInStatus === "pending") {
      signals.pendingCheckIn = 6;
      danger += 6;
    }

    if ((ctx.journeyOvertimeMin ?? 0) > 10) {
      const w = Math.min(18, 6 + (ctx.journeyOvertimeMin! - 10) * 0.8);
      signals.journeyOvertime = Math.round(w);
      danger += w;
      reasons.push(`Journey ${Math.round(ctx.journeyOvertimeMin!)} min beyond expected duration`);
    }

    if ((ctx.prolongedStopMin ?? 0) > 5) {
      const w = Math.min(15, 5 + ctx.prolongedStopMin!);
      signals.prolongedStop = Math.round(w);
      danger += w;
      reasons.push(`Unexpected prolonged stop (${Math.round(ctx.prolongedStopMin!)} min)`);
    }

    if (ctx.userReportedDistress) {
      signals.userDistress = 45;
      danger += 45;
      reasons.push("User reported a threatening situation to the AI Guardian");
    }

    if ((ctx.voiceDistressConfidence ?? 0) > 0.65) {
      const w = 25 * ctx.voiceDistressConfidence!;
      signals.voiceDistress = Math.round(w);
      danger += w;
      reasons.push(`Distress detected in voice tone (${Math.round(ctx.voiceDistressConfidence! * 100)}% confidence)`);
    }

    const hour = ctx.hour ?? new Date().getHours();
    if ((hour >= 22 || hour < 5) && danger > 0) {
      signals.lateNight = 8;
      danger += 8;
      reasons.push("Late-night hours amplify contextual risk");
    }

    // Corroboration bonus: independent signals together mean more than alone
    const independent = Object.values(signals).filter((v) => v >= 10).length;
    if (independent >= 2) {
      danger += independent * 6;
      reasons.push(`${independent} independent risk signals corroborate each other`);
    }

    danger = Math.min(100, Math.round(danger));
    const riskScore = 100 - danger;

    let riskLevel: RiskLevel = "LOW";
    if (danger >= 70) riskLevel = "CRITICAL";
    else if (danger >= 45) riskLevel = "HIGH";
    else if (danger >= 20) riskLevel = "MEDIUM";

    const activeSignals = Object.values(signals).filter((v) => v >= 10).length;
    const confidence = Math.min(0.98, 0.35 + activeSignals * 0.18 + (ctx.explicitSos ? 0.5 : 0));

    const recommendedAction =
      riskLevel === "CRITICAL"
        ? "Activate emergency workflow: notify contacts, share live location, evaluate escalation policy"
        : riskLevel === "HIGH"
          ? "Send safety check; if unanswered, alert trusted contacts and share live location"
          : riskLevel === "MEDIUM"
            ? "Increase monitoring frequency and send a safety check"
            : "Continue routine monitoring";

    if (reasons.length === 0) reasons.push("No active risk signals");

    return {
      riskLevel,
      riskScore,
      confidence: Math.round(confidence * 100) / 100,
      reasons,
      recommendedAction,
      requiresVerification: riskLevel === "HIGH" || riskLevel === "MEDIUM",
      signals,
    };
  }
}

// Simple distress-signal detection on user text (stands in for the multimodal
// perception layer; the interface is pluggable with an LLM endpoint).
const DISTRESS_PATTERNS = [
  /following me/i, /being followed/i, /help me/i, /scared/i, /threaten/i,
  /won'?t leave me alone/i, /grab(bed)?/i, /attack/i, /danger/i, /unsafe/i,
  /harass/i, /stalking/i, /someone.*(behind|chasing)/i, /please help/i,
  /can'?t (breathe|move|get away)/i, /kidnap/i, /weapon/i, /knife|gun/i,
];
const CANT_TALK = [/can'?t talk/i, /cannot talk/i, /don'?t speak/i, /have to be quiet/i, /silent/i];
const SAFE = [/^i'?m safe/i, /^i am (fine|safe|okay|ok)/i, /all good/i, /false alarm/i];

export function analyzeUserMessage(text: string): {
  distress: boolean;
  cantTalk: boolean;
  declaresSafe: boolean;
  matched: string[];
} {
  const matched = DISTRESS_PATTERNS.filter((p) => p.test(text)).map((p) => p.source);
  return {
    distress: matched.length > 0,
    cantTalk: CANT_TALK.some((p) => p.test(text)),
    declaresSafe: SAFE.some((p) => p.test(text)),
    matched,
  };
}

export function nearestZone(
  zones: { label: string; centerLat: number; centerLng: number; radiusM: number; riskScore: number }[],
  p: LatLng,
  distFn: (a: LatLng, b: LatLng) => number,
) {
  for (const z of zones) {
    if (distFn(p, { lat: z.centerLat, lng: z.centerLng }) <= z.radiusM) return z;
  }
  return null;
}
