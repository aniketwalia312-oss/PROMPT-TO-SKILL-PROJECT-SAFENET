// ReportAI — multimodal report classification (text/photo-description).
// Rule-based NLP adapter with the same interface an LLM classifier would use;
// swap the internals for a vision/chat model endpoint when credentials exist.

const CATEGORY_RULES: { category: string; patterns: RegExp[]; baseSeverity: "LOW" | "MEDIUM" | "HIGH" }[] = [
  { category: "Broken Streetlight", patterns: [/street\s?light/i, /lamp/i, /light(ing)? (is )?(out|off|broken|not working)/i, /dark (street|road|lane|alley)/i, /pitch black/i, /flicker/i], baseSeverity: "HIGH" },
  { category: "Harassment Report", patterns: [/harass/i, /catcall/i, /following/i, /stalking/i, /loiter/i, /eve.?teas/i, /grope/i, /uncomfortable/i], baseSeverity: "HIGH" },
  { category: "Unsafe Crossing", patterns: [/crossing/i, /zebra/i, /signal/i, /traffic/i, /speeding/i, /jaywalk/i, /intersection/i], baseSeverity: "MEDIUM" },
  { category: "Suspicious Activity", patterns: [/suspicious/i, /stranger/i, /watching/i, /peeking/i, /tamper/i, /lurking/i], baseSeverity: "MEDIUM" },
  { category: "Stray Dogs", patterns: [/dog/i, /stray/i, /bark/i, /bite/i, /pack of/i], baseSeverity: "MEDIUM" },
  { category: "Poor Infrastructure", patterns: [/pothole/i, /broken (road|footpath|pavement)/i, /construction/i, /debris/i, /flooded/i, /open (drain|manhole)/i], baseSeverity: "MEDIUM" },
  { category: "Isolated Area", patterns: [/isolated/i, /deserted/i, /no people/i, /empty/i, /abandoned/i], baseSeverity: "MEDIUM" },
  { category: "Theft Risk", patterns: [/theft/i, /stolen/i, /snatch/i, /pickpocket/i, /robber/i], baseSeverity: "HIGH" },
];

const SEVERITY_BOOSTERS = [/night/i, /dark/i, /alone/i, /women/i, /children/i, /repeatedly/i, /daily/i, /every (night|evening)/i, /multiple/i, /gang|group/i, /weapon|knife|drunk/i];

export interface ReportAnalysis {
  category: string;
  severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  confidence: number;
  summary: string;
  factors: string[];
}

export class ReportAI {
  static analyze(description: string): ReportAnalysis {
    let category = "General Safety Concern";
    let severity: ReportAnalysis["severity"] = "LOW";
    let best = 0;
    for (const rule of CATEGORY_RULES) {
      const hits = rule.patterns.filter((p) => p.test(description)).length;
      if (hits > best) {
        best = hits;
        category = rule.category;
        severity = rule.baseSeverity;
      }
    }
    const factors: string[] = [];
    let boost = 0;
    for (const p of SEVERITY_BOOSTERS) {
      if (p.test(description)) {
        boost++;
        factors.push(p.source.replace(/\//g, "").replace(/\^|\$|\?/g, ""));
      }
    }
    if (boost >= 2 && severity === "MEDIUM") severity = "HIGH";
    else if (boost >= 1 && severity === "LOW") severity = "MEDIUM";
    if (/weapon|knife|gun|assault|attack/i.test(description)) severity = "CRITICAL";

    const words = description.trim().split(/\s+/).length;
    const confidence = Math.min(0.97, 0.55 + best * 0.12 + Math.min(0.15, words * 0.01));

    const summaryMap: Record<string, string> = {
      "Broken Streetlight": "Poor lighting may reduce visibility and increase risk on this stretch.",
      "Harassment Report": "Harassment pattern reported at this location; elevated caution advised.",
      "Unsafe Crossing": "Uncontrolled or dangerous crossing on an active road.",
      "Suspicious Activity": "Suspicious behavior reported; area may warrant monitoring.",
      "Stray Dogs": "Animal-related risk, particularly during low-activity hours.",
      "Poor Infrastructure": "Physical hazard that could cause injury or reduce safe passage.",
      "Isolated Area": "Low foot traffic and isolation may increase vulnerability.",
      "Theft Risk": "Theft or snatching risk reported in this area.",
      "General Safety Concern": "Community-reported safety concern requiring review.",
    };

    return {
      category,
      severity,
      confidence: Math.round(confidence * 100) / 100,
      summary: summaryMap[category],
      factors: factors.slice(0, 5),
    };
  }
}
