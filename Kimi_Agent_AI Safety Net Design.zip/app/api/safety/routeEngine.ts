import { getDb } from "../queries/connection";
import { safetyZones, safetyReports, safePlaces } from "@db/schema";
import { haversineM, polylineLengthM, pointToPolylineM, type LatLng } from "./geo";

export interface RouteOption {
  id: string;
  label: string;
  path: LatLng[];
  distanceM: number;
  durationMin: number;
  safetyScore: number; // 0-100
  reasons: string[];
  recommended: boolean;
}

// Deterministic safety-aware routing:
// generates candidate polylines between origin and destination, then scores each
// against risk zones, community reports, time-of-day and safe-place coverage.
export class SafetyRouteEngine {
  static candidates(origin: LatLng, dest: LatLng): { id: string; label: string; path: LatLng[] }[] {
    const mid: LatLng = { lat: (origin.lat + dest.lat) / 2, lng: (origin.lng + dest.lng) / 2 };
    // perpendicular offset for alternative corridors
    const dLat = dest.lat - origin.lat;
    const dLng = dest.lng - origin.lng;
    const len = Math.hypot(dLat, dLng) || 1;
    const perp = { lat: -dLng / len, lng: dLat / len };
    const off = len * 0.28;

    const direct: LatLng[] = [origin, mid, dest];
    const north: LatLng[] = [
      origin,
      { lat: mid.lat + perp.lat * off, lng: mid.lng + perp.lng * off },
      dest,
    ];
    const south: LatLng[] = [
      origin,
      { lat: mid.lat - perp.lat * off, lng: mid.lng - perp.lng * off },
      dest,
    ];
    return [
      { id: "A", label: "Direct Route", path: direct },
      { id: "B", label: "Via North Corridor", path: north },
      { id: "C", label: "Via South Corridor", path: south },
    ];
  }

  static async plan(origin: LatLng, dest: LatLng): Promise<RouteOption[]> {
    const db = getDb();
    const [zones, reports, places] = await Promise.all([
      db.select().from(safetyZones),
      db.select().from(safetyReports),
      db.select().from(safePlaces),
    ]);

    const hour = new Date().getHours();
    const isNight = hour >= 20 || hour < 6;

    const options = this.candidates(origin, dest).map((c) => {
      let score = 92;
      const reasons: string[] = [];

      // Risk zones near path
      for (const z of zones) {
        const d = pointToPolylineM({ lat: z.centerLat, lng: z.centerLng }, c.path);
        if (d < z.radiusM) {
          const penalty = Math.round(z.riskScore * (isNight ? 0.45 : 0.3));
          score -= penalty;
          reasons.push(
            `Passes through ${z.label} (risk ${z.riskScore}/100, ${z.incidentCount} reports)`,
          );
        } else if (d < z.radiusM + 150) {
          score -= Math.round(z.riskScore * 0.12);
          reasons.push(`Passes near ${z.label}`);
        }
      }

      // Community reports near path
      let nearbyReports = 0;
      for (const r of reports) {
        if (r.status === "dismissed" || r.status === "resolved") continue;
        const d = pointToPolylineM({ lat: r.latitude, lng: r.longitude }, c.path);
        if (d < 180) {
          nearbyReports++;
          score -= r.severity === "HIGH" ? 6 : r.severity === "CRITICAL" ? 9 : 3;
        }
      }
      if (nearbyReports > 0)
        reasons.push(`${nearbyReports} community report${nearbyReports > 1 ? "s" : ""} along this corridor`);

      // Safe-place coverage (bonus)
      let safeCoverage = 0;
      for (const p of places) {
        if (pointToPolylineM({ lat: p.latitude, lng: p.longitude }, c.path) < 250) safeCoverage++;
      }
      if (safeCoverage > 0) {
        score += Math.min(8, safeCoverage * 3);
        reasons.push(`${safeCoverage} verified safe place${safeCoverage > 1 ? "s" : ""} within 250m`);
      }

      // Night penalty for isolation
      if (isNight) reasons.push("Night-time weighting applied (lighting & foot traffic)");

      const distanceM = Math.round(polylineLengthM(c.path));
      // walking speed ~ 5 km/h
      const durationMin = Math.max(1, Math.round(distanceM / 83.3));
      score = Math.max(5, Math.min(99, Math.round(score)));

      return {
        id: c.id,
        label: c.label,
        path: c.path,
        distanceM,
        durationMin,
        safetyScore: score,
        reasons,
        recommended: false,
      };
    });

    // Recommended = highest safety score (not shortest)
    const best = options.reduce((a, b) => (b.safetyScore > a.safetyScore ? b : a));
    best.recommended = true;
    best.reasons.unshift("Recommended — highest overall safety score");
    return options.sort((a, b) => b.safetyScore - a.safetyScore);
  }

  static async nearestSafePlaces(from: LatLng, limit = 3) {
    const places = await getDb().select().from(safePlaces);
    return places
      .map((p) => ({
        ...p,
        distanceM: Math.round(haversineM(from, { lat: p.latitude, lng: p.longitude })),
      }))
      .sort((a, b) => {
        // rank: verified & open first, then distance
        const ra = (a.verified ? 0 : 1) + (a.open24h ? 0 : 0.5);
        const rb = (b.verified ? 0 : 1) + (b.open24h ? 0 : 0.5);
        return ra !== rb ? ra - rb : a.distanceM - b.distanceM;
      })
      .slice(0, limit);
  }
}
