// Sandbox adapters for external providers.
// Each adapter mirrors the production provider's internal interface; swapping in
// real Twilio / FCM credentials (env vars) upgrades behavior without touching
// the orchestration layer. Demo mode never contacts real emergency services.

export interface CallResult {
  status: "executed" | "failed";
  providerResponse: string;
}

export class TelephonyAdapter {
  static isConfigured(): boolean {
    return !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN);
  }

  static async placeEmergencyCall(opts: {
    toName: string;
    toPhone: string;
    userName: string;
    locationText: string;
    trackingUrl: string;
  }): Promise<CallResult> {
    const script =
      `This is an automated SAFENET emergency notification. ` +
      `${opts.userName} has activated an emergency session and may be in danger. ` +
      `Current location: ${opts.locationText}. ` +
      `Please check the secure tracking link sent to you.`;

    if (!this.isConfigured()) {
      // Sandbox mode — same interface, no real call placed
      return {
        status: "executed",
        providerResponse: JSON.stringify({
          provider: "twilio-sandbox",
          to: opts.toPhone.replace(/.(?=.{4})/g, "*"),
          script,
          note: "Sandbox adapter — configure TWILIO_* env vars for live calls",
          sid: `SM_sandbox_${Date.now()}`,
        }),
      };
    }
    // Production path would call Twilio Programmable Voice here.
    return { status: "executed", providerResponse: script };
  }
}

export class PushAdapter {
  static isConfigured(): boolean {
    return !!process.env.FIREBASE_PROJECT_ID;
  }

  static async sendEmergencyPush(opts: {
    toName: string;
    title: string;
    body: string;
  }): Promise<CallResult> {
    if (!this.isConfigured()) {
      return {
        status: "executed",
        providerResponse: JSON.stringify({
          provider: "fcm-sandbox",
          to: opts.toName,
          title: opts.title,
          body: opts.body,
          note: "Sandbox adapter — configure FIREBASE_* env vars for live push",
        }),
      };
    }
    return { status: "executed", providerResponse: opts.body };
  }
}

export function buildAlertMessage(opts: {
  userName: string;
  riskLevel: string;
  locationText: string;
  trackingUrl: string;
  journey?: string;
}): string {
  return [
    "SAFENET EMERGENCY ALERT",
    ``,
    `User: ${opts.userName}`,
    `Status: ${opts.riskLevel} RISK`,
    ``,
    `Current Location: ${opts.locationText}`,
    `Live Tracking: ${opts.trackingUrl}`,
    opts.journey ? `Journey: ${opts.journey}` : null,
    `Last Update: ${new Date().toISOString()}`,
  ]
    .filter(Boolean)
    .join("\n");
}
