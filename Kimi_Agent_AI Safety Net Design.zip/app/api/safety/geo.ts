// Geospatial helpers (no external GIS dependency — haversine on WGS84)
export type LatLng = { lat: number; lng: number };

const R = 6371000; // meters
const rad = (d: number) => (d * Math.PI) / 180;

export function haversineM(a: LatLng, b: LatLng): number {
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

// Distance from point p to segment ab (meters), equirectangular approx (fine < 5km)
export function pointToSegmentM(p: LatLng, a: LatLng, b: LatLng): number {
  const lat0 = rad((a.lat + b.lat) / 2);
  const px = rad(p.lng) * R * Math.cos(lat0);
  const py = rad(p.lat) * R;
  const ax = rad(a.lng) * R * Math.cos(lat0);
  const ay = rad(a.lat) * R;
  const bx = rad(b.lng) * R * Math.cos(lat0);
  const by = rad(b.lat) * R;
  const dx = bx - ax;
  const dy = by - ay;
  const len2 = dx * dx + dy * dy;
  let t = len2 === 0 ? 0 : ((px - ax) * dx + (py - ay) * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  const cx = ax + t * dx;
  const cy = ay + t * dy;
  return Math.hypot(px - cx, py - cy);
}

export function pointToPolylineM(p: LatLng, line: LatLng[]): number {
  if (line.length === 0) return Infinity;
  if (line.length === 1) return haversineM(p, line[0]);
  let min = Infinity;
  for (let i = 0; i < line.length - 1; i++) {
    min = Math.min(min, pointToSegmentM(p, line[i], line[i + 1]));
  }
  return min;
}

export function polylineLengthM(line: LatLng[]): number {
  let d = 0;
  for (let i = 0; i < line.length - 1; i++) d += haversineM(line[i], line[i + 1]);
  return d;
}

export function interpolatePolyline(line: LatLng[], frac: number): LatLng {
  const total = polylineLengthM(line);
  let target = total * Math.max(0, Math.min(1, frac));
  for (let i = 0; i < line.length - 1; i++) {
    const seg = haversineM(line[i], line[i + 1]);
    if (target <= seg) {
      const t = seg === 0 ? 0 : target / seg;
      return {
        lat: line[i].lat + (line[i + 1].lat - line[i].lat) * t,
        lng: line[i].lng + (line[i + 1].lng - line[i].lng) * t,
      };
    }
    target -= seg;
  }
  return line[line.length - 1];
}
