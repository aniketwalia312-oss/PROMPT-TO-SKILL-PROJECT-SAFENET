import { getDb } from "../queries/connection";
import {
  journeys,
  journeyStates,
  locationPoints,
  safetyEvents,
  safetyZones,
  emergencySessions,
  emergencyActions,
  incidentTimeline,
  trustedContacts,
  safetySettings,
  guardianMessages,
  users,
} from "@db/schema";
import { eq, desc, and } from "drizzle-orm";
import { randomBytes } from "crypto";
import { pointToPolylineM, haversineM, type LatLng } from "./geo";
import { ThreatAssessmentEngine, nearestZone, type ThreatAssessment } from "./threatEngine";
import { SafetyPolicyEngine, type PolicyAction } from "./policyEngine";
import { TelephonyAdapter, PushAdapter, buildAlertMessage } from "./adapters";
import type { SafetySettings } from "@db/schema";

// ─── Safety Orchestration Engine ─────────────────────────────────
// Location/anomaly events flow: perception → threat assessment → policy engine
// → idempotent action execution → timeline audit log.

async function addTimeline(entry: {
  sessionId?: number | null;
  journeyId?: number | null;
  event: string;
  description?: string;
  timestamp?: Date;
}) {
  await getDb().insert(incidentTimeline).values({
    sessionId: entry.sessionId ?? null,
    journeyId: entry.journeyId ?? null,
    event: entry.event,
    description: entry.description ?? null,
    ...(entry.timestamp ? { timestamp: entry.timestamp } : {}),
  });
}

async function logSafetyEvent(e: {
  journeyId?: number | null;
  sessionId?: number | null;
  eventType: string;
  severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  confidence?: number;
  lat?: number;
  lng?: number;
  metadata?: unknown;
  timestamp?: Date;
}) {
  await getDb().insert(safetyEvents).values({
    journeyId: e.journeyId ?? null,
    sessionId: e.sessionId ?? null,
    eventType: e.eventType,
    severity: e.severity,
    confidence: e.confidence ?? null,
    latitude: e.lat ?? null,
    longitude: e.lng ?? null,
    metadata: e.metadata ? JSON.parse(JSON.stringify(e.metadata)) : null,
    ...(e.timestamp ? { timestamp: e.timestamp } : {}),
  });
}

export async function getSettings(userId: number): Promise<SafetySettings> {
  const db = getDb();
  const [s] = await db.select().from(safetySettings).where(eq(safetySettings.userId, userId));
  if (s) return s;
  await db.insert(safetySettings).values({ userId });
  const [created] = await db.select().from(safetySettings).where(eq(safetySettings.userId, userId));
  return created!;
}

// Idempotent action execution: sessionId + actionType + target is the key.
async function executeAction(
  sessionId: number,
  action: PolicyAction,
  ctx: { userName: string; locationText: string; trackingUrl: string; journey?: string },
): Promise<{ executed: boolean; duplicate: boolean }> {
  const db = getDb();
  const key = `${sessionId}:${action.actionType}:${action.target}`;
  const existing = await db
    .select()
    .from(emergencyActions)
    .where(eq(emergencyActions.idempotencyKey, key))
    .limit(1);
  if (existing.length > 0) return { executed: false, duplicate: true };

  let status: "executed" | "failed" | "skipped" = "executed";
  let providerResponse = "";
  try {
    if (action.actionType === "call_contact") {
      const [contact] = await db
        .select()
        .from(trustedContacts)
        .where(and(eq(trustedContacts.name, action.target)));
      const r = await TelephonyAdapter.placeEmergencyCall({
        toName: action.target,
        toPhone: contact?.phone ?? "+1-555-0100-DEMO",
        userName: ctx.userName,
        locationText: ctx.locationText,
        trackingUrl: ctx.trackingUrl,
      });
      status = r.status;
      providerResponse = r.providerResponse;
    } else if (action.actionType === "notify_contact") {
      const r = await PushAdapter.sendEmergencyPush({
        toName: action.target,
        title: "SAFENET EMERGENCY ALERT",
        body: buildAlertMessage({
          userName: ctx.userName,
          riskLevel: "HIGH",
          locationText: ctx.locationText,
          trackingUrl: ctx.trackingUrl,
          journey: ctx.journey,
        }),
      });
      status = r.status;
      providerResponse = r.providerResponse;
    } else if (action.actionType === "escalate_emergency_services") {
      const r = await TelephonyAdapter.placeEmergencyCall({
        toName: "Verified Emergency Service",
        toPhone: "112",
        userName: ctx.userName,
        locationText: ctx.locationText,
        trackingUrl: ctx.trackingUrl,
      });
      status = r.status;
      providerResponse = r.providerResponse;
    } else {
      providerResponse = action.reason;
    }
  } catch (err) {
    status = "failed";
    providerResponse = String(err);
  }

  await db.insert(emergencyActions).values({
    sessionId,
    actionType: action.actionType,
    target: action.target,
    status,
    providerResponse,
    idempotencyKey: key,
  });
  return { executed: true, duplicate: false };
}

export class SafetyOrchestrator {
  // ── Journey lifecycle ──────────────────────────────────────────
  static async startJourney(input: {
    userId: number;
    origin: string;
    destination: string;
    originLat: number;
    originLng: number;
    destLat: number;
    destLng: number;
    routeId: string;
    plannedRoute: LatLng[];
    routeSafetyScore: number;
    durationMin: number;
  }) {
    const db = getDb();
    const expected = new Date(Date.now() + input.durationMin * 60000);
    const [{ id }] = await db
      .insert(journeys)
      .values({
        userId: input.userId,
        origin: input.origin,
        destination: input.destination,
        originLat: input.originLat,
        originLng: input.originLng,
        destLat: input.destLat,
        destLng: input.destLng,
        routeId: input.routeId,
        plannedRoute: input.plannedRoute,
        routeSafetyScore: input.routeSafetyScore,
        expectedArrival: expected,
        status: "active",
      })
      .$returningId();
    await db.insert(journeyStates).values({
      journeyId: id,
      riskScore: input.routeSafetyScore,
      riskLevel: "LOW",
    });
    await db.insert(locationPoints).values({
      journeyId: id,
      latitude: input.originLat,
      longitude: input.originLng,
    });
    await addTimeline({
      journeyId: id,
      event: "Journey Started",
      description: `${input.origin} → ${input.destination} (route safety ${input.routeSafetyScore}/100)`,
    });
    return id;
  }

  static async completeJourney(journeyId: number) {
    const db = getDb();
    await db
      .update(journeys)
      .set({ status: "completed", actualArrival: new Date() })
      .where(eq(journeys.id, journeyId));
    await addTimeline({ journeyId, event: "Journey Completed", description: "User arrived safely" });
  }

  // ── Location ingestion + anomaly detection + threat assessment ──
  static async ingestLocation(journeyId: number, point: LatLng & { speed?: number }) {
    const db = getDb();
    const [journey] = await db.select().from(journeys).where(eq(journeys.id, journeyId));
    if (!journey || journey.status !== "active") return null;

    await db.insert(locationPoints).values({
      journeyId,
      latitude: point.lat,
      longitude: point.lng,
      speed: point.speed ?? null,
    });

    const [state] = await db.select().from(journeyStates).where(eq(journeyStates.journeyId, journeyId));
    const zones = await db.select().from(safetyZones);
    const planned = (journey.plannedRoute as LatLng[]) ?? [];

    // Anomaly signals
    const deviationM = planned.length > 1 ? pointToPolylineM(point, planned) : 0;
    const zone = nearestZone(zones, point, haversineM);
    const overtimeMin = journey.expectedArrival
      ? Math.max(0, (Date.now() - new Date(journey.expectedArrival).getTime()) / 60000)
      : 0;

    const isDeviation = deviationM > 120;
    if (isDeviation && state) {
      await db
        .update(journeyStates)
        .set({ deviationCount: (state?.deviationCount ?? 0) + 1, lastAnomalyAt: new Date() })
        .where(eq(journeyStates.journeyId, journeyId));
      await logSafetyEvent({
        journeyId,
        eventType: "route_deviation",
        severity: "MEDIUM",
        lat: point.lat,
        lng: point.lng,
        metadata: { deviationM: Math.round(deviationM) },
      });
      await addTimeline({
        journeyId,
        event: "Route Deviation Detected",
        description: `${Math.round(deviationM)}m off planned route`,
      });
    }
    if (zone && zone.riskScore >= 60) {
      await logSafetyEvent({
        journeyId,
        eventType: "high_risk_zone_entry",
        severity: "MEDIUM",
        lat: point.lat,
        lng: point.lng,
        metadata: { zone: zone.label, riskScore: zone.riskScore },
      });
    }

    // Threat assessment (signal fusion)
    const assessment = ThreatAssessmentEngine.assess({
      routeDeviationM: deviationM,
      inHighRiskZone: zone ? { label: zone.label, riskScore: zone.riskScore } : null,
      checkInStatus: state?.checkInStatus ?? "none",
      journeyOvertimeMin: overtimeMin,
    });

    await db
      .update(journeyStates)
      .set({
        riskScore: assessment.riskScore,
        riskLevel: assessment.riskLevel,
        threatAssessment: JSON.parse(JSON.stringify(assessment)),
      })
      .where(eq(journeyStates.journeyId, journeyId));

    if (assessment.riskLevel === "MEDIUM" || assessment.riskLevel === "HIGH") {
      await addTimeline({
        journeyId,
        event: `Risk Level: ${assessment.riskLevel}`,
        description: assessment.reasons.join("; "),
      });
      // Policy engine: MEDIUM/HIGH (answered) → safety check
      if (state?.checkInStatus === "none" || state?.checkInStatus === "answered") {
        await this.sendSafetyCheck(journeyId, assessment);
      }
    }
    return { assessment, deviationM: Math.round(deviationM), zone: zone?.label ?? null };
  }

  static async sendSafetyCheck(journeyId: number, assessment?: ThreatAssessment) {
    const db = getDb();
    await db
      .update(journeyStates)
      .set({ checkInStatus: "pending", checkInSentAt: new Date() })
      .where(eq(journeyStates.journeyId, journeyId));
    const [journey] = await db.select().from(journeys).where(eq(journeys.id, journeyId));
    await db.insert(guardianMessages).values({
      journeyId,
      userId: journey!.userId,
      role: "guardian",
      content:
        "I detected a significant route change. Are you safe?",
    });
    await addTimeline({
      journeyId,
      event: "Safety Check Sent",
      description: assessment ? `Triggered by ${assessment.riskLevel} risk` : undefined,
    });
  }

  static async answerCheckIn(journeyId: number, safe: boolean) {
    const db = getDb();
    await db
      .update(journeyStates)
      .set({ checkInStatus: safe ? "answered" : "missed" })
      .where(eq(journeyStates.journeyId, journeyId));
    await addTimeline({
      journeyId,
      event: safe ? "User Confirmed Safe" : "User Requested Help",
    });
    if (safe) {
      await db
        .update(journeyStates)
        .set({ riskScore: 85, riskLevel: "LOW" })
        .where(eq(journeyStates.journeyId, journeyId));
    }
    return safe;
  }

  // Missed check-in → reassess with NO_RESPONSE → policy engine decides
  static async markCheckInMissed(journeyId: number) {
    const db = getDb();
    const [journey] = await db.select().from(journeys).where(eq(journeys.id, journeyId));
    if (!journey) return null;
    await db
      .update(journeyStates)
      .set({ checkInStatus: "missed" })
      .where(eq(journeyStates.journeyId, journeyId));
    await addTimeline({ journeyId, event: "Safety Check Unanswered" });

    const points = await db
      .select()
      .from(locationPoints)
      .where(eq(locationPoints.journeyId, journeyId))
      .orderBy(desc(locationPoints.timestamp))
      .limit(1);
    const last = points[0];
    const zones = await db.select().from(safetyZones);
    const planned = (journey.plannedRoute as LatLng[]) ?? [];
    const loc: LatLng = last
      ? { lat: last.latitude, lng: last.longitude }
      : { lat: journey.originLat, lng: journey.originLng };

    const assessment = ThreatAssessmentEngine.assess({
      routeDeviationM: planned.length > 1 ? pointToPolylineM(loc, planned) : 0,
      inHighRiskZone: (() => {
        const z = nearestZone(zones, loc, haversineM);
        return z ? { label: z.label, riskScore: z.riskScore } : null;
      })(),
      checkInStatus: "missed",
    });

    await db
      .update(journeyStates)
      .set({
        riskScore: assessment.riskScore,
        riskLevel: assessment.riskLevel,
        threatAssessment: JSON.parse(JSON.stringify(assessment)),
      })
      .where(eq(journeyStates.journeyId, journeyId));
    await addTimeline({
      journeyId,
      event: `Risk Increased: ${assessment.riskLevel}`,
      description: assessment.reasons.join("; "),
    });

    if (assessment.riskLevel === "HIGH" || assessment.riskLevel === "CRITICAL") {
      // Policy engine: HIGH + NO_RESPONSE → escalate to emergency session
      return this.activateEmergency({
        userId: journey.userId,
        journeyId,
        method: "auto_anomaly",
        location: loc,
        assessment,
      });
    }
    return { assessment };
  }

  // ── Emergency activation (state machine entry) ─────────────────
  static async activateEmergency(input: {
    userId: number;
    journeyId?: number | null;
    method: "sos_button" | "voice_trigger" | "discreet_trigger" | "auto_anomaly" | "demo";
    location: LatLng;
    assessment?: ThreatAssessment;
  }) {
    const db = getDb();
    // one active session per user
    const existing = await db
      .select()
      .from(emergencySessions)
      .where(and(eq(emergencySessions.userId, input.userId), eq(emergencySessions.status, "active")))
      .limit(1);
    if (existing.length > 0) return { session: existing[0], alreadyActive: true };

    const assessment =
      input.assessment ??
      ThreatAssessmentEngine.assess({ explicitSos: input.method === "sos_button" || input.method === "voice_trigger" || input.method === "discreet_trigger" });

    const shareToken = randomBytes(16).toString("hex");
    const [{ id: sessionId }] = await db
      .insert(emergencySessions)
      .values({
        userId: input.userId,
        journeyId: input.journeyId ?? null,
        activationMethod: input.method,
        riskLevel: assessment.riskLevel,
        state: "EMERGENCY_ACTIVE",
        shareToken,
        lastLat: input.location.lat,
        lastLng: input.location.lng,
      })
      .$returningId();

    if (input.journeyId) {
      await db.update(journeys).set({ status: "emergency" }).where(eq(journeys.id, input.journeyId));
    }

    const [user] = await db.select().from(users).where(eq(users.id, input.userId));
    const settings = await getSettings(input.userId);
    const contacts = await db
      .select()
      .from(trustedContacts)
      .where(eq(trustedContacts.userId, input.userId));
    const [journey] = input.journeyId
      ? await db.select().from(journeys).where(eq(journeys.id, input.journeyId))
      : [null];

    await addTimeline({
      sessionId,
      journeyId: input.journeyId,
      event: "Emergency Session Activated",
      description: `Activation: ${input.method}. Risk: ${assessment.riskLevel} (confidence ${assessment.confidence})`,
    });
    await logSafetyEvent({
      journeyId: input.journeyId,
      sessionId,
      eventType: "emergency_activated",
      severity: assessment.riskLevel,
      lat: input.location.lat,
      lng: input.location.lng,
      metadata: { method: input.method, signals: assessment.signals },
    });

    // ── Policy engine decides actions (deterministic) ──
    const decision = SafetyPolicyEngine.decide(
      assessment,
      {
        escalateToContacts: settings.escalateToContacts,
        escalateToEmergencyServices: settings.escalateToEmergencyServices,
        autoCallContacts: settings.autoCallContacts,
        locationSharingEnabled: settings.locationSharingEnabled,
      },
      {
        explicitSos: input.method !== "auto_anomaly",
        checkInUnanswered: true,
        contacts: contacts.map((c) => ({
          id: Number(c.id),
          name: c.name,
          priority: c.priority,
          callEnabled: c.callEnabled,
          notificationEnabled: c.notificationEnabled,
        })),
      },
    );

    const trackingUrl = `/track/${shareToken}`;
    const locationText = `${input.location.lat.toFixed(5)}, ${input.location.lng.toFixed(5)}`;
    const execCtx = {
      userName: user?.name ?? "SAFENET user",
      locationText,
      trackingUrl,
      journey: journey ? `${journey.origin} → ${journey.destination}` : undefined,
    };

    for (const action of decision.actions) {
      if (action.actionType === "log_only" || action.actionType === "safety_check") continue;
      const r = await executeAction(sessionId, action, execCtx);
      if (r.executed) {
        const label =
          action.actionType === "notify_contact"
            ? `Trusted Contact Notified: ${action.target}`
            : action.actionType === "call_contact"
              ? `Emergency Call Placed: ${action.target}`
              : action.actionType === "share_live_location"
                ? "Live Location Sharing Started"
                : action.actionType === "escalate_emergency_services"
                  ? "Emergency Service Escalation Initiated"
                  : "AI Guardian Voice Session Started";
        await addTimeline({ sessionId, journeyId: input.journeyId, event: label, description: action.reason });
      }
    }

    await db
      .update(emergencySessions)
      .set({ state: "CONTACTS_NOTIFIED" })
      .where(eq(emergencySessions.id, sessionId));

    // Guardian opening message
    await db.insert(guardianMessages).values({
      sessionId,
      journeyId: input.journeyId,
      userId: input.userId,
      role: "guardian",
      content:
        "I'm here. Your live location is now shared with your trusted contacts. Are you able to speak? Stay in a populated area if you can.",
    });

    const [session] = await db.select().from(emergencySessions).where(eq(emergencySessions.id, sessionId));
    return { session: session!, decision, alreadyActive: false };
  }

  static async updateSessionLocation(sessionId: number, loc: LatLng) {
    await getDb()
      .update(emergencySessions)
      .set({ lastLat: loc.lat, lastLng: loc.lng })
      .where(eq(emergencySessions.id, sessionId));
  }

  static async resolveEmergency(sessionId: number, userId: number, cancelled = false) {
    const db = getDb();
    await db
      .update(emergencySessions)
      .set({ status: cancelled ? "cancelled" : "resolved", endedAt: new Date(), state: "RESOLVED" })
      .where(eq(emergencySessions.id, sessionId));
    const [session] = await db.select().from(emergencySessions).where(eq(emergencySessions.id, sessionId));
    if (session?.journeyId) {
      await db
        .update(journeys)
        .set({ status: "active" })
        .where(eq(journeys.id, session.journeyId));
      await db
        .update(journeyStates)
        .set({ riskScore: 90, riskLevel: "LOW", checkInStatus: "none" })
        .where(eq(journeyStates.journeyId, session.journeyId));
    }
    await addTimeline({
      sessionId,
      journeyId: session?.journeyId,
      event: cancelled ? "Emergency Cancelled by User" : "Emergency Resolved",
      description: cancelled ? "User confirmed false alarm" : "User confirmed safe — session closed",
    });
    await db.insert(guardianMessages).values({
      sessionId,
      journeyId: session?.journeyId ?? null,
      userId,
      role: "guardian",
      content: cancelled
        ? "Understood — emergency cancelled. I'll keep monitoring your journey."
        : "Glad you're safe. Emergency session closed. Your contacts have been notified that you're OK.",
    });
  }
}
