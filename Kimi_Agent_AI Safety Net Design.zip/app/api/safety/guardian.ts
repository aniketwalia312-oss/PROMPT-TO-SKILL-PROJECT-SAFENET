import { getDb } from "../queries/connection";
import {
  guardianMessages,
  emergencySessions,
  journeys,
  journeyStates,
} from "@db/schema";
import { eq, desc, asc } from "drizzle-orm";
import { analyzeUserMessage, ThreatAssessmentEngine } from "./threatEngine";
import { SafetyOrchestrator } from "./orchestrator";
import { SafetyRouteEngine } from "./routeEngine";
import { locationPoints } from "@db/schema";

// SAFENET GUARDIAN — safety-focused conversational layer.
// Short, calm, direct, actionable. It interprets user messages for distress
// signals and feeds the ThreatAssessmentEngine; it never executes irreversible
// emergency actions itself — the SafetyPolicyEngine owns final decisions.

export class Guardian {
  static async history(userId: number, sessionId?: number | null, journeyId?: number | null) {
    const db = getDb();
    const rows = sessionId
      ? await db.select().from(guardianMessages).where(eq(guardianMessages.sessionId, sessionId)).orderBy(asc(guardianMessages.timestamp))
      : journeyId
        ? await db.select().from(guardianMessages).where(eq(guardianMessages.journeyId, journeyId)).orderBy(asc(guardianMessages.timestamp))
        : await db.select().from(guardianMessages).where(eq(guardianMessages.userId, userId)).orderBy(desc(guardianMessages.timestamp)).limit(30);
    return rows;
  }

  static async reply(input: {
    userId: number;
    text: string;
    sessionId?: number | null;
    journeyId?: number | null;
    location?: { lat: number; lng: number };
  }) {
    const db = getDb();
    await db.insert(guardianMessages).values({
      userId: input.userId,
      sessionId: input.sessionId ?? null,
      journeyId: input.journeyId ?? null,
      role: "user",
      content: input.text,
    });

    const analysis = analyzeUserMessage(input.text);
    let response: string;
    let escalated = false;

    if (analysis.declaresSafe && input.sessionId) {
      await SafetyOrchestrator.resolveEmergency(input.sessionId, input.userId);
      return { response: "Glad you're safe. Closing the emergency session now.", escalated: false, resolved: true };
    }

    if (analysis.cantTalk) {
      response =
        "Understood. Stay silent if necessary — your configured emergency response is active. Tap I'M SAFE or I NEED HELP when you can.";
      if (!input.sessionId && input.journeyId) {
        await this.escalateFromDistress(input, "User cannot speak — silent emergency protocol");
        escalated = true;
      }
    } else if (analysis.distress) {
      response =
        "I understand. Stay in a populated, well-lit area if possible. I'm escalating your status now — your trusted contacts are being notified. Keep moving toward a safe place.";
      if (!input.sessionId) {
        await this.escalateFromDistress(input, `User reported: "${input.text.slice(0, 120)}"`);
        escalated = true;
      }
    } else if (/safe place|police|hospital|navigate/i.test(input.text)) {
      const loc = input.location ?? (await this.lastKnownLocation(input.journeyId));
      if (loc) {
        const places = await SafetyRouteEngine.nearestSafePlaces(loc, 3);
        const list = places
          .map((p, i) => `${i + 1}. ${p.name} — ${p.distanceM}m${p.open24h ? " (open 24h)" : ""}`)
          .join("\n");
        response = `Nearest safe options:\n${list}\nHead to the closest one. I'm monitoring.`;
      } else {
        response = "I need your location to find safe places. Enable location sharing.";
      }
    } else if (input.sessionId) {
      response =
        "I'm here with you. Your live location is being shared. If the situation changes, tell me — or tap I NEED HELP to escalate further.";
    } else {
      response =
        "I'm monitoring your journey. If anything feels wrong, say so — one word is enough. I can also guide you to the nearest safe place.";
    }

    await db.insert(guardianMessages).values({
      userId: input.userId,
      sessionId: input.sessionId ?? null,
      journeyId: input.journeyId ?? null,
      role: "guardian",
      content: response,
    });

    return { response, escalated, resolved: false, distressDetected: analysis.distress };
  }

  private static async lastKnownLocation(journeyId?: number | null) {
    if (!journeyId) return null;
    const [p] = await getDb()
      .select()
      .from(locationPoints)
      .where(eq(locationPoints.journeyId, journeyId))
      .orderBy(desc(locationPoints.timestamp))
      .limit(1);
    return p ? { lat: p.latitude, lng: p.longitude } : null;
  }

  // Distress reported via chat during monitoring → fuse with context → CRITICAL
  private static async escalateFromDistress(
    input: { userId: number; journeyId?: number | null; location?: { lat: number; lng: number } },
    reason: string,
  ) {
    const db = getDb();
    const loc = input.location ?? (await this.lastKnownLocation(input.journeyId)) ?? { lat: 12.9352, lng: 77.6245 };
    let prior: { riskScore: number; checkInStatus: "none" | "pending" | "answered" | "missed" } | null = null;
    if (input.journeyId) {
      const [s] = await db.select().from(journeyStates).where(eq(journeyStates.journeyId, input.journeyId));
      prior = s ? { riskScore: s.riskScore, checkInStatus: s.checkInStatus } : null;
    }
    const assessment = ThreatAssessmentEngine.assess({
      userReportedDistress: true,
      checkInStatus: prior?.checkInStatus ?? "none",
      routeDeviationM: prior && prior.riskScore < 70 ? 200 : 0,
    });
    await SafetyOrchestrator.activateEmergency({
      userId: input.userId,
      journeyId: input.journeyId ?? null,
      method: "auto_anomaly",
      location: loc,
      assessment,
    });
    if (input.journeyId) {
      const [j] = await db.select().from(journeys).where(eq(journeys.id, input.journeyId));
      void j;
    }
    return { reason, assessment };
  }
}
