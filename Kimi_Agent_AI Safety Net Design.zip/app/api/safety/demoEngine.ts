import { getDb } from "../queries/connection";
import { journeys, journeyStates, guardianMessages } from "@db/schema";
import { eq } from "drizzle-orm";
import { SafetyOrchestrator } from "./orchestrator";
import { SafetyRouteEngine } from "./routeEngine";
import { Guardian } from "./guardian";
import { interpolatePolyline, type LatLng } from "./geo";
import type { RiskLevel } from "./threatEngine";

// Demo / simulation mode — runs REAL orchestrator operations against the live
// database and engines, with scripted movement and timing. Nothing is faked at
// the engine level; only the GPS input and clock are simulated. Telephony/push
// run through sandbox adapters, so no real emergency service is ever contacted.

export type DemoScenarioId =
  | "route_deviation"
  | "no_response"
  | "silent_emergency"
  | "explicit_sos"
  | "critical_escalation";

interface DemoState {
  scenario: DemoScenarioId;
  step: number;
  journeyId: number;
  path: LatLng[];
  deviationPath: LatLng[];
  sessionId?: number;
}

const demos = new Map<number, DemoState>();

export const SCENARIOS: { id: DemoScenarioId; name: string; description: string }[] = [
  { id: "route_deviation", name: "Scenario 1 — Route Deviation", description: "User strays from planned route, Guardian verifies, user confirms safe." },
  { id: "no_response", name: "Scenario 2 — No Response", description: "Deviation + unanswered safety check escalates to trusted-contact alerts." },
  { id: "silent_emergency", name: "Scenario 3 — Silent Emergency", description: "User can't speak; a two-word message triggers the silent protocol." },
  { id: "explicit_sos", name: "Scenario 4 — Explicit SOS", description: "One press. Full configured emergency workflow fires immediately." },
  { id: "critical_escalation", name: "Scenario 5 — Critical Escalation", description: "Deviation + high-risk zone + no response + reported distress → CRITICAL." },
];

const ORIGIN = { label: "Greenfield University — Main Gate", lat: 12.9368, lng: 77.6278 };
const DEST = { label: "Hostel Block C", lat: 12.933, lng: 77.6264 };

export class DemoEngine {
  static status(userId: number) {
    const d = demos.get(userId);
    return d ? { running: true, scenario: d.scenario, step: d.step } : { running: false };
  }

  static async start(userId: number, scenario: DemoScenarioId) {
    await this.stop(userId);
    const db = getDb();

    const routes = await SafetyRouteEngine.plan(
      { lat: ORIGIN.lat, lng: ORIGIN.lng },
      { lat: DEST.lat, lng: DEST.lng },
    );
    const best = routes[0];
    const journeyId = await SafetyOrchestrator.startJourney({
      userId,
      origin: ORIGIN.label,
      destination: DEST.label,
      originLat: ORIGIN.lat,
      originLng: ORIGIN.lng,
      destLat: DEST.lat,
      destLng: DEST.lng,
      routeId: best.id,
      plannedRoute: best.path,
      routeSafetyScore: best.safetyScore,
      durationMin: best.durationMin,
    });

    // scripted deviation corridor through the Riverfront Underpass risk zone
    const deviationPath: LatLng[] = [
      best.path[0],
      { lat: 12.9342, lng: 77.6282 },
      { lat: 12.9316, lng: 77.629 }, // inside underpass zone
      { lat: 12.9318, lng: 77.6272 },
      best.path[best.path.length - 1],
    ];

    if (scenario === "explicit_sos") {
      const { session } = await SafetyOrchestrator.activateEmergency({
        userId,
        journeyId,
        method: "demo",
        location: { lat: ORIGIN.lat, lng: ORIGIN.lng },
      });
      demos.set(userId, { scenario, step: 1, journeyId, path: best.path, deviationPath, sessionId: session.id });
    } else {
      demos.set(userId, { scenario, step: 0, journeyId, path: best.path, deviationPath });
    }
    return { journeyId, scenario };
  }

  static async stop(userId: number) {
    const d = demos.get(userId);
    if (d?.sessionId) {
      try { await SafetyOrchestrator.resolveEmergency(d.sessionId, userId, true); } catch { /* noop */ }
    }
    if (d?.journeyId) {
      const db = getDb();
      const [j] = await db.select().from(journeys).where(eq(journeys.id, d.journeyId));
      if (j?.status === "active") await SafetyOrchestrator.completeJourney(d.journeyId);
    }
    demos.delete(userId);
  }

  // Advance the scripted scenario by one beat. Returns a UI-facing status line.
  static async tick(userId: number): Promise<{ done: boolean; note: string; riskLevel?: RiskLevel }> {
    const d = demos.get(userId);
    if (!d) return { done: true, note: "No demo running" };
    const db = getDb();
    const step = d.step;

    const move = async (path: LatLng[], frac: number) => {
      const p = interpolatePolyline(path, frac);
      const r = await SafetyOrchestrator.ingestLocation(d.journeyId, { ...p, speed: 4.5 });
      if (d.sessionId) await SafetyOrchestrator.updateSessionLocation(d.sessionId, p);
      return r;
    };
    const risk = async () => {
      const [s] = await db.select().from(journeyStates).where(eq(journeyStates.journeyId, d.journeyId));
      return s?.riskLevel as RiskLevel | undefined;
    };
    const advance = (note: string, riskLevel?: RiskLevel) => {
      d.step++;
      return { done: false, note, riskLevel };
    };

    switch (d.scenario) {
      case "explicit_sos": {
        if (step === 1) return advance("SOS received → emergency session active. Policy engine executed configured workflow (notify + call + live location).", "CRITICAL");
        if (step === 2) { await move(d.path, 0.3); return advance("Live location streaming to trusted contacts.", "CRITICAL"); }
        if (step === 3) { await move(d.path, 0.6); return advance("AI Guardian voice session active. Nearest safe places computed.", "CRITICAL"); }
        return { done: true, note: "Scenario complete — emergency remains active until user taps I'M SAFE.", riskLevel: "CRITICAL" };
      }

      case "route_deviation": {
        if (step === 0) { await move(d.path, 0.25); return advance("Journey underway — on planned route."); }
        if (step === 1) { await move(d.path, 0.5); return advance("On route. Monitoring signals normal."); }
        if (step === 2) { await move(d.deviationPath, 0.4); return advance("Route deviation detected → risk rising.", await risk()); }
        if (step === 3) return advance("Guardian: \"Your route has changed significantly. Are you safe?\"", await risk());
        if (step === 4) {
          await SafetyOrchestrator.answerCheckIn(d.journeyId, true);
          await db.insert(guardianMessages).values({ journeyId: d.journeyId, userId, role: "user", content: "I'm safe — just grabbing something from the store." });
          await db.insert(guardianMessages).values({ journeyId: d.journeyId, userId, role: "guardian", content: "Thanks for confirming. Resuming normal monitoring." });
          return advance("User confirmed safe → risk reset, monitoring continues.", "LOW");
        }
        if (step === 5) { await move(d.path, 0.8); return advance("Back on planned route."); }
        await SafetyOrchestrator.completeJourney(d.journeyId);
        demos.delete(userId);
        return { done: true, note: "Journey completed safely. No escalation was needed — single weak signals never trigger emergencies.", riskLevel: "LOW" };
      }

      case "no_response": {
        if (step === 0) { await move(d.path, 0.3); return advance("Journey underway."); }
        if (step === 1) { await move(d.deviationPath, 0.45); return advance("Route deviation detected.", await risk()); }
        if (step === 2) return advance("Safety check sent. Waiting for response…", await risk());
        if (step === 3) return advance("No response. Timer running…", await risk());
        if (step === 4) {
          const r = await SafetyOrchestrator.markCheckInMissed(d.journeyId);
          if (r && "session" in r) d.sessionId = r.session.id;
          return advance("Check-in missed + deviation = HIGH risk → policy engine alerts trusted contacts, live location shared.", await risk() ?? "HIGH");
        }
        if (step === 5) { await move(d.deviationPath, 0.6); return advance("Contacts notified. Tracking link active. Guardian awaiting user response.", "HIGH"); }
        return { done: true, note: "Scenario complete — emergency active. Resolve it from the emergency screen.", riskLevel: "HIGH" };
      }

      case "silent_emergency": {
        if (step === 0) { await move(d.path, 0.35); return advance("Journey underway."); }
        if (step === 1) { await move(d.deviationPath, 0.5); return advance("Deviation detected → safety check sent.", await risk()); }
        if (step === 2) {
          const r = await Guardian.reply({
            userId,
            journeyId: d.journeyId,
            text: "Can't talk. Someone nearby.",
            location: interpolatePolyline(d.deviationPath, 0.5),
          });
          void r;
          const sess = await this.findSession(d.journeyId);
          if (sess) d.sessionId = sess.id;
          return advance("User: \"Can't talk.\" → silent emergency protocol → emergency session activated.", await risk());
        }
        if (step === 3) {
          const sess = await this.findSession(d.journeyId);
          if (sess) d.sessionId = sess.id;
          return advance("Contacts notified via push + automated call. Guardian switched to one-tap interaction mode.", "HIGH");
        }
        return { done: true, note: "Scenario complete — silent emergency active with minimal-interaction UI.", riskLevel: "HIGH" };
      }

      case "critical_escalation": {
        if (step === 0) { await move(d.path, 0.3); return advance("Journey underway — route safety 91."); }
        if (step === 1) { await move(d.deviationPath, 0.5); return advance("Route deviation detected → risk 91 → 62.", await risk()); }
        if (step === 2) return advance("Guardian: \"Your route has changed significantly. Are you safe?\"", await risk());
        if (step === 3) return advance("No response…", await risk());
        if (step === 4) {
          const r = await SafetyOrchestrator.markCheckInMissed(d.journeyId);
          if (r && "session" in r) d.sessionId = r.session.id;
          return advance("Deviation + high-risk zone + no response → risk 78 (HIGH). Contacts alerted.", "HIGH");
        }
        if (step === 5) {
          const sess = await this.findSession(d.journeyId);
          if (sess) d.sessionId = sess.id;
          await Guardian.reply({
            userId,
            journeyId: d.journeyId,
            sessionId: d.sessionId ?? null,
            text: "Someone is following me.",
            location: interpolatePolyline(d.deviationPath, 0.6),
          });
          return advance("User: \"Someone is following me.\" → distress confirmed → CRITICAL.", "CRITICAL");
        }
        if (step === 6) {
          const loc = interpolatePolyline(d.deviationPath, 0.6);
          const places = await SafetyRouteEngine.nearestSafePlaces(loc, 3);
          return advance(`Emergency workflow complete. Nearest safe place: ${places[0]?.name} (${places[0]?.distanceM}m).`, "CRITICAL");
        }
        return { done: true, note: "Scenario complete — full escalation chain executed and logged on the incident timeline.", riskLevel: "CRITICAL" };
      }
    }
    return { done: true, note: "Unknown scenario" };
  }

  private static async findSession(journeyId: number) {
    const db = getDb();
    const { emergencySessions } = await import("@db/schema");
    const [s] = await db
      .select()
      .from(emergencySessions)
      .where(eq(emergencySessions.journeyId, journeyId))
      .orderBy(emergencySessions.startedAt);
    return s ?? null;
  }
}
