import type { RiskLevel, ThreatAssessment } from "./threatEngine";

export interface EscalationPolicy {
  escalateToContacts: boolean;
  escalateToEmergencyServices: boolean;
  autoCallContacts: boolean;
  locationSharingEnabled: boolean;
}

export interface PolicyDecision {
  actions: PolicyAction[];
  rationale: string[];
}

export interface PolicyAction {
  actionType:
    | "safety_check"
    | "notify_contact"
    | "call_contact"
    | "share_live_location"
    | "escalate_emergency_services"
    | "guardian_voice_session"
    | "log_only";
  target: string; // contact id/name or service identifier
  reason: string;
}

// SafetyPolicyEngine — DETERMINISTIC decision layer.
// The AI (threat assessment, guardian) interprets; only this engine may decide
// which emergency actions execute. Every decision is explainable and auditable.
export class SafetyPolicyEngine {
  static decide(
    assessment: ThreatAssessment,
    policy: EscalationPolicy,
    context: {
      explicitSos: boolean;
      checkInUnanswered: boolean;
      contacts: { id: number; name: string; priority: number; callEnabled: boolean; notificationEnabled: boolean }[];
    },
  ): PolicyDecision {
    const actions: PolicyAction[] = [];
    const rationale: string[] = [];
    const level: RiskLevel = assessment.riskLevel;
    const contacts = [...context.contacts].sort((a, b) => a.priority - b.priority);

    if (context.explicitSos || level === "CRITICAL") {
      rationale.push(
        context.explicitSos
          ? "RULE: explicit_sos = TRUE → activate emergency workflow immediately"
          : "RULE: risk = CRITICAL → full emergency response",
      );
      if (policy.locationSharingEnabled) {
        actions.push({
          actionType: "share_live_location",
          target: "trusted_contacts",
          reason: "Live location sharing enabled in user policy",
        });
      }
      if (policy.escalateToContacts) {
        for (const c of contacts.filter((c) => c.notificationEnabled)) {
          actions.push({
            actionType: "notify_contact",
            target: c.name,
            reason: `Trusted contact (priority ${c.priority}) — risk ${level}`,
          });
        }
        if (policy.autoCallContacts) {
          for (const c of contacts.filter((c) => c.callEnabled)) {
            actions.push({
              actionType: "call_contact",
              target: c.name,
              reason: `Auto-call enabled — outbound voice notification`,
            });
          }
        }
      }
      actions.push({
        actionType: "guardian_voice_session",
        target: "user",
        reason: "AI Guardian realtime session for verification and guidance",
      });
      if (policy.escalateToEmergencyServices) {
        actions.push({
          actionType: "escalate_emergency_services",
          target: "verified_emergency_service",
          reason: "Escalation policy permits emergency-service workflow",
        });
      } else {
        rationale.push(
          "RULE: escalate_emergency_services requires explicit user opt-in — skipped",
        );
      }
      return { actions, rationale };
    }

    if (level === "HIGH") {
      if (context.checkInUnanswered) {
        rationale.push(
          "RULE: risk = HIGH AND user_response = NO_RESPONSE AND escalation_policy = TRUE → notify trusted contacts",
        );
        if (policy.escalateToContacts) {
          for (const c of contacts.filter((c) => c.notificationEnabled)) {
            actions.push({
              actionType: "notify_contact",
              target: c.name,
              reason: "HIGH risk with unanswered safety check",
            });
          }
        }
        if (policy.locationSharingEnabled) {
          actions.push({
            actionType: "share_live_location",
            target: "trusted_contacts",
            reason: "Precautionary live location share",
          });
        }
      } else {
        rationale.push("RULE: risk = HIGH → request safety verification first");
        actions.push({
          actionType: "safety_check",
          target: "user",
          reason: "Verify user safety before alerting contacts",
        });
      }
      return { actions, rationale };
    }

    if (level === "MEDIUM") {
      rationale.push("RULE: risk = MEDIUM → verify with user, increase monitoring");
      actions.push({
        actionType: "safety_check",
        target: "user",
        reason: "Anomaly detected — confirm safety",
      });
      return { actions, rationale };
    }

    rationale.push("RULE: risk = LOW → routine monitoring, no action");
    actions.push({ actionType: "log_only", target: "system", reason: "No threshold crossed" });
    return { actions, rationale };
  }
}
