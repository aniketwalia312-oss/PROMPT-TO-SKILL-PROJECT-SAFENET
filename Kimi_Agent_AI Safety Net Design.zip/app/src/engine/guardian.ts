// SAFENET GUARDIAN — safety-focused conversational layer.
// Short, calm, direct, actionable. Never verbose during danger.

export interface GuardianResult {
  reply: string;
  intent:
    | 'DANGER_FOLLOWED'
    | 'DANGER_GENERIC'
    | 'CANT_TALK'
    | 'SAFE'
    | 'NEED_HELP'
    | 'CALL_CONTACT'
    | 'NAVIGATE_SAFE'
    | 'TRIGGER_PHRASE'
    | 'SMALLTALK'
    | 'UNKNOWN';
  userReportedDanger: boolean;
  userReportedSafe: boolean;
  requestsEscalation: boolean;
}

export function guardianRespond(raw: string, emergencyActive: boolean, triggerPhrase: string): GuardianResult {
  const text = raw.toLowerCase().trim();

  const base: GuardianResult = {
    reply: '',
    intent: 'UNKNOWN',
    userReportedDanger: false,
    userReportedSafe: false,
    requestsEscalation: false,
  };

  if (triggerPhrase && text.includes(triggerPhrase.toLowerCase())) {
    return { ...base, intent: 'TRIGGER_PHRASE', reply: 'Emergency trigger recognized. Activating your configured response now.', requestsEscalation: true };
  }

  if (/(follow|following|stalk)/.test(text)) {
    return {
      ...base,
      intent: 'DANGER_FOLLOWED',
      userReportedDanger: true,
      reply:
        "I'm here. Stay in a populated, lit area if you can. Your live location is being shared with your trusted contacts. Do not confront them. Can you move toward the nearest safe place?",
    };
  }

  if (/(can'?t talk|cannot talk|can'?t speak|silent|be quiet)/.test(text)) {
    return {
      ...base,
      intent: 'CANT_TALK',
      reply: 'Understood. Stay silent if necessary — no reply needed. Your configured emergency response is active and your location is live.',
    };
  }

  if (/(i'?m safe|i am safe|all good|i'?m fine|safe now|reached)/.test(text)) {
    return {
      ...base,
      intent: 'SAFE',
      userReportedSafe: true,
      reply: 'Good to hear. I\'ll keep monitoring quietly. Tap "I\'M SAFE" on the emergency screen to stand down fully.',
    };
  }

  if (/(help|danger|scared|emergency|attack|threat|unsafe|someone)/.test(text)) {
    return {
      ...base,
      intent: 'DANGER_GENERIC',
      userReportedDanger: true,
      requestsEscalation: emergencyActive,
      reply: emergencyActive
        ? 'Understood. Your contacts have been alerted and your location is live. Move toward people and light. I\'m finding your nearest safe place now.'
        : 'I\'m here. Tell me what\'s happening in a few words — or press and hold SOS if you\'re in immediate danger.',
    };
  }

  if (/(call|phone)/.test(text)) {
    return { ...base, intent: 'CALL_CONTACT', requestsEscalation: true, reply: 'Calling your priority contact now. Stay on this screen.' };
  }

  if (/(safe place|navigate|where.*go|police|hospital)/.test(text)) {
    return { ...base, intent: 'NAVIGATE_SAFE', reply: 'Your nearest verified safe places are listed below. Head toward the closest one — it\'s open and staffed.' };
  }

  if (/^(hi|hello|hey|good)/.test(text)) {
    return {
      ...base,
      intent: 'SMALLTALK',
      reply: 'Hello — I\'m your SAFENET Guardian. I monitor your journeys and I\'m here the moment something feels wrong.',
    };
  }

  return {
    ...base,
    reply: emergencyActive
      ? 'I\'m listening. Use the quick replies if typing is hard — one tap is enough.'
      : 'Noted. If you ever feel unsafe, say so in a few words or hold the SOS button — I\'ll take it from there.',
  };
}

export function guardianProactive(kind: 'DEVIATION' | 'CHECK' | 'RISK_UP' | 'CONTACTS_SENT' | 'SAFE_PLACE'): string {
  switch (kind) {
    case 'DEVIATION':
      return 'I detected a significant change from your planned route. Are you safe?';
    case 'CHECK':
      return 'Safety check — one tap "I\'M SAFE" is all I need.';
    case 'RISK_UP':
      return 'Your risk level has risen. I\'ve alerted your trusted contacts and started live location sharing.';
    case 'CONTACTS_SENT':
      return 'Your trusted contacts have been notified and can see your live location.';
    case 'SAFE_PLACE':
      return 'Nearest safe options are on screen. The closest is a short walk — head there if you can.';
  }
}
