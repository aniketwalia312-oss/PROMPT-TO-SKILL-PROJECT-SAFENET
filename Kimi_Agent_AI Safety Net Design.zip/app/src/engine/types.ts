// SAFENET core domain types

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type EmergencyState =
  | 'IDLE'
  | 'JOURNEY_ACTIVE'
  | 'MONITORING'
  | 'ANOMALY_DETECTED'
  | 'SAFETY_CHECK'
  | 'WARNING'
  | 'EMERGENCY_ACTIVE'
  | 'CONTACTS_NOTIFIED'
  | 'ESCALATION_PENDING'
  | 'ESCALATED'
  | 'RESOLVED';

export type ActivationMethod = 'SOS_BUTTON' | 'VOICE_TRIGGER' | 'ANOMALY' | 'SIMULATION';

export interface LatLng {
  lat: number;
  lng: number;
}

export interface TrustedContact {
  id: string;
  name: string;
  phone: string;
  relationship: string;
  priority: number;
  notificationEnabled: boolean;
  callEnabled: boolean;
}

export interface RouteOption {
  id: string;
  label: string;
  kind: 'FASTEST' | 'SAFEST';
  path: LatLng[];
  minutes: number;
  distanceKm: number;
  safetyScore: number;
  explanation: string;
}

export interface Journey {
  id: string;
  originName: string;
  destName: string;
  origin: LatLng;
  destination: LatLng;
  route: RouteOption;
  startedAt: number;
  expectedMinutes: number;
  positionIdx: number;
  deviated: boolean;
  deviationMeters: number;
  stoppedTicks: number;
  missedChecks: number;
  status: 'ACTIVE' | 'COMPLETED' | 'INTERRUPTED';
}

export interface RiskAssessment {
  riskLevel: RiskLevel;
  riskScore: number; // 0-100 (higher = more danger)
  confidence: number; // 0-100
  reasons: string[];
  recommendedAction: string;
  requiresVerification: boolean;
  timestamp: number;
}

export interface TimelineEvent {
  id: string;
  time: number;
  event: string;
  description: string;
  severity: RiskLevel | 'INFO';
}

export type ActionType =
  | 'SEND_SAFETY_CHECK'
  | 'NOTIFY_CONTACT'
  | 'SHARE_LOCATION'
  | 'START_GUARDIAN_VOICE'
  | 'PLACE_CALL'
  | 'ESCALATE_EMERGENCY_SERVICES'
  | 'PUSH_NOTIFICATION';

export interface EmergencyAction {
  id: string; // idempotency key: sessionId:actionType:target
  sessionId: string;
  actionType: ActionType;
  target: string;
  status: 'EXECUTED' | 'FAILED' | 'BLOCKED_DUPLICATE';
  provider: string;
  providerResponse: string;
  timestamp: number;
}

export interface EmergencySession {
  id: string;
  activationMethod: ActivationMethod;
  state: EmergencyState;
  riskLevel: RiskLevel;
  startedAt: number;
  endedAt?: number;
  locationShared: boolean;
  silent: boolean;
}

export interface SafetyZone {
  id: string;
  name: string;
  center: LatLng;
  radiusMeters: number;
  riskScore: number; // 0-100, higher = more dangerous
  incidentCount: number;
  category: string;
}

export interface SafePlace {
  id: string;
  name: string;
  category: 'POLICE' | 'HOSPITAL' | 'TRANSIT' | 'PUBLIC' | 'PHARMACY';
  position: LatLng;
  open24h: boolean;
  verified: boolean;
}

export interface SafetyReport {
  id: string;
  author: string;
  category: string;
  description: string;
  position: LatLng;
  severity: RiskLevel;
  confidence: number;
  aiSummary: string;
  hasPhoto: boolean;
  status: 'VERIFIED' | 'PENDING';
  createdAt: number;
}

export interface ChatMessage {
  id: string;
  from: 'GUARDIAN' | 'USER' | 'SYSTEM';
  text: string;
  time: number;
}

export interface SafetyCheck {
  sentAtTick: number;
  reason: string;
  answered: boolean;
}

export interface Settings {
  autoNotifyContacts: boolean;
  escalateToServices: boolean;
  shareLocationOnEmergency: boolean;
  voiceTriggerEnabled: boolean;
  voicePhrase: string;
  retentionDays: number;
}

export interface ThreatContext {
  explicitSOS: boolean;
  routeDeviationMeters: number;
  inHighRiskZone: boolean;
  zoneRiskScore: number;
  missedCheckIns: number;
  unexpectedStopTicks: number;
  journeyOvertimeRatio: number;
  userReportedDanger: boolean;
  userReportedSafe: boolean;
  hourOfDay: number;
  nearbyReportCount: number;
}
