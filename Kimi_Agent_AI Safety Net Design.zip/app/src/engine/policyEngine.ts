import type { ActionType, EmergencyState, RiskAssessment, Settings, TrustedContact } from './types';

export interface PolicyDecision {
  actionType: ActionType;
  target: string; // contact id, 'ALL_CONTACTS', 'USER', 'EMERGENCY_SERVICES'
  reason: string;
}

/**
 * SafetyPolicyEngine — deterministic rules. The AI interprets;
 * ONLY this engine decides irreversible actions. Every decision is auditable.
 */
export function evaluatePolicy(input: {
  assessment: RiskAssessment;
  state: EmergencyState;
  settings: Settings;
  contacts: TrustedContact[];
  explicitSOS: boolean;
  userUnresponsive: boolean;
}): PolicyDecision[] {
  const { assessment, settings, contacts, explicitSOS, userUnresponsive } = input;
  const decisions: PolicyDecision[] = [];
  const notifiable = contacts.filter((c) => c.notificationEnabled).sort((a, b) => a.priority - b.priority);

  // RULE 1 — Explicit SOS: activate configured workflow immediately
  if (explicitSOS) {
    decisions.push({ actionType: 'SHARE_LOCATION', target: 'ALL_CONTACTS', reason: 'Explicit SOS — live location sharing' });
    for (const c of notifiable) {
      decisions.push({ actionType: 'NOTIFY_CONTACT', target: c.id, reason: 'Explicit SOS — notify trusted contact' });
      if (c.callEnabled && c.priority === 1) {
        decisions.push({ actionType: 'PLACE_CALL', target: c.id, reason: 'Explicit SOS — call priority-1 contact' });
      }
    }
    decisions.push({ actionType: 'START_GUARDIAN_VOICE', target: 'USER', reason: 'Explicit SOS — open Guardian channel' });
    if (settings.escalateToServices) {
      decisions.push({
        actionType: 'ESCALATE_EMERGENCY_SERVICES',
        target: 'EMERGENCY_SERVICES',
        reason: 'Explicit SOS — user policy permits emergency-service escalation',
      });
    }
    return decisions;
  }

  // RULE 2 — MEDIUM risk with unanswered signals: verify first
  if (assessment.riskLevel === 'MEDIUM' && assessment.requiresVerification) {
    decisions.push({ actionType: 'SEND_SAFETY_CHECK', target: 'USER', reason: 'Elevated signals — verify user safety before any alert' });
    return decisions;
  }

  // RULE 3 — HIGH risk + user unresponsive + policy allows: notify contacts
  if (assessment.riskLevel === 'HIGH' && userUnresponsive && settings.autoNotifyContacts) {
    decisions.push({ actionType: 'SHARE_LOCATION', target: 'ALL_CONTACTS', reason: 'HIGH risk + no user response — live location sharing' });
    for (const c of notifiable) {
      decisions.push({ actionType: 'NOTIFY_CONTACT', target: c.id, reason: 'HIGH risk + no user response' });
    }
    decisions.push({ actionType: 'START_GUARDIAN_VOICE', target: 'USER', reason: 'HIGH risk — open Guardian verification channel' });
    return decisions;
  }

  // RULE 4 — HIGH risk but user responsive: keep verifying
  if (assessment.riskLevel === 'HIGH' && !userUnresponsive) {
    decisions.push({ actionType: 'SEND_SAFETY_CHECK', target: 'USER', reason: 'HIGH risk — re-verify before escalation' });
    return decisions;
  }

  // RULE 5 — CRITICAL: full configured escalation
  if (assessment.riskLevel === 'CRITICAL') {
    decisions.push({ actionType: 'SHARE_LOCATION', target: 'ALL_CONTACTS', reason: 'CRITICAL risk — live location sharing' });
    for (const c of notifiable) {
      decisions.push({ actionType: 'NOTIFY_CONTACT', target: c.id, reason: 'CRITICAL risk — notify trusted contact' });
      if (c.callEnabled && c.priority <= 2) {
        decisions.push({ actionType: 'PLACE_CALL', target: c.id, reason: 'CRITICAL risk — call high-priority contact' });
      }
    }
    decisions.push({ actionType: 'START_GUARDIAN_VOICE', target: 'USER', reason: 'CRITICAL risk — Guardian active' });
    if (settings.escalateToServices) {
      decisions.push({
        actionType: 'ESCALATE_EMERGENCY_SERVICES',
        target: 'EMERGENCY_SERVICES',
        reason: 'CRITICAL risk — user policy permits emergency-service escalation',
      });
    }
  }

  return decisions;
}
