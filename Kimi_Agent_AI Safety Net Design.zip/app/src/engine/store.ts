import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  ActivationMethod,
  ChatMessage,
  EmergencyAction,
  EmergencySession,
  EmergencyState,
  Journey,
  LatLng,
  RiskAssessment,
  RiskLevel,
  SafetyCheck,
  SafetyReport,
  Settings,
  TimelineEvent,
  TrustedContact,
} from './types';
import { CITY_CENTER, DEMO_CONTACTS, EMERGENCY_SERVICES, SAFE_PLACES, SAFETY_ZONES, SEED_REPORTS, buildRoutes, getPlace } from './cityData';
import { distanceToPath, haversineMeters, offsetPoint, pointAlongPath } from './geo';
import { assessThreat } from './threatEngine';
import { evaluatePolicy, type PolicyDecision } from './policyEngine';
import { guardianProactive, guardianRespond } from './guardian';
import { analyzeReport } from './reportAI';

let uid = 0;
const nid = () => `id-${Date.now()}-${uid++}`;

const JOURNEY_TICKS = 60; // a full demo journey lasts ~60 ticks (1 tick = 1s)
const CHECK_DEADLINE_TICKS = 15;

export interface FeedItem {
  id: string;
  time: number;
  kind: 'PUSH' | 'SMS' | 'CALL' | 'SYSTEM';
  title: string;
  body: string;
}

interface SafeNetState {
  user: { name: string } | null;
  contacts: TrustedContact[];
  reports: SafetyReport[];
  settings: Settings;

  journey: Journey | null;
  tickCount: number;
  position: LatLng;

  risk: RiskAssessment;
  emergency: EmergencySession | null;
  timeline: TimelineEvent[];
  actions: EmergencyAction[];
  guardianMessages: ChatMessage[];
  safetyCheck: SafetyCheck | null;
  feed: FeedItem[];

  scenario: number | null;
  scenarioTick: number;

  // actions
  login: (name: string) => void;
  logout: () => void;
  addContact: (c: Omit<TrustedContact, 'id'>) => void;
  removeContact: (id: string) => void;
  updateSettings: (s: Partial<Settings>) => void;

  startJourney: (originId: string, destId: string, routeId: string) => void;
  endJourney: (completed: boolean) => void;
  tick: () => void;

  triggerSOS: (method: ActivationMethod) => void;
  answerSafetyCheck: (safe: boolean) => void;
  sendUserMessage: (text: string) => void;
  callForHelp: () => void;
  resolveEmergency: () => void;

  submitReport: (description: string, hasPhoto: boolean, position: LatLng) => SafetyReport;
  runScenario: (n: number) => void;
  resetDemo: () => void;
}

const initialRisk: RiskAssessment = {
  riskLevel: 'LOW',
  riskScore: 4,
  confidence: 95,
  reasons: ['No active threat signals'],
  recommendedAction: 'Continue monitoring',
  requiresVerification: false,
  timestamp: Date.now(),
};

function zoneAt(p: LatLng) {
  let best: { zone: (typeof SAFETY_ZONES)[number]; inside: boolean } | null = null;
  for (const zone of SAFETY_ZONES) {
    const d = haversineMeters(p, zone.center);
    if (d < zone.radiusMeters) {
      if (!best || zone.riskScore > best.zone.riskScore) best = { zone, inside: true };
    }
  }
  return best;
}

function nearbyReports(p: LatLng, reports: SafetyReport[]) {
  return reports.filter((r) => haversineMeters(p, r.position) < 600).length;
}

export const useSafeNet = create<SafeNetState>()(
  persist(
    (set, get) => {
      // ---- internal helpers (closed over set/get) ----

      const log = (event: string, description: string, severity: RiskLevel | 'INFO' = 'INFO') => {
        set((s) => ({
          timeline: [...s.timeline, { id: nid(), time: Date.now(), event, description, severity }],
        }));
      };

      const pushFeed = (kind: FeedItem['kind'], title: string, body: string) => {
        set((s) => ({ feed: [{ id: nid(), time: Date.now(), kind, title, body }, ...s.feed].slice(0, 40) }));
      };

      const guardianSay = (text: string, from: 'GUARDIAN' | 'SYSTEM' = 'GUARDIAN') => {
        set((s) => ({ guardianMessages: [...s.guardianMessages, { id: nid(), from, text, time: Date.now() }] }));
      };

      const setState = (state: EmergencyState, description: string) => {
        const e = get().emergency;
        if (!e) return;
        set({ emergency: { ...e, state } });
        log(`State → ${state}`, description, 'INFO');
      };

      /** Idempotent execution of a policy decision. Key = session:action:target. */
      const execute = (sessionId: string, d: PolicyDecision) => {
        const key = `${sessionId}:${d.actionType}:${d.target}`;
        const existing = get().actions.find((a) => a.id === key);
        if (existing) {
          set((s) => ({
            actions: [...s.actions, { ...existing, id: nid(), status: 'BLOCKED_DUPLICATE' as const, timestamp: Date.now(), providerResponse: 'Duplicate blocked by idempotency key' }],
          }));
          return;
        }

        const contacts = get().contacts;
        let targetLabel = d.target;
        let provider = 'safenet-core';
        let providerResponse = 'ok';

        if (d.actionType === 'NOTIFY_CONTACT' || d.actionType === 'PLACE_CALL') {
          const c = contacts.find((x) => x.id === d.target);
          targetLabel = c ? `${c.name} · ${c.phone}` : d.target;
          if (d.actionType === 'NOTIFY_CONTACT') {
            provider = 'firebase-admin (sandbox)';
            providerResponse = 'FCM sandbox: push delivered';
            pushFeed('PUSH', `SAFENET EMERGENCY ALERT → ${c?.name}`, `Status: HIGH RISK · Live tracking link sent · ${get().journey ? `${get().journey!.originName} → ${get().journey!.destName}` : 'No active journey'}`);
          } else {
            provider = 'twilio-voice (sandbox)';
            providerResponse = 'Twilio sandbox: outbound call initiated (mock, no real call placed)';
            pushFeed('CALL', `Automated call → ${c?.name}`, '"This is an automated SAFENET emergency notification. A SAFENET user has activated an emergency session and may be in danger. Please check the secure tracking link sent to you."');
          }
        }
        if (d.actionType === 'SHARE_LOCATION') {
          provider = 'safenet-realtime';
          providerResponse = 'Live tracking session created · expiring link generated';
          pushFeed('SMS', 'Live location sharing started', 'Secure tracking link sent to trusted contacts (expires with session).');
          const e = get().emergency;
          if (e) set({ emergency: { ...e, locationShared: true } });
          log('Live Location Sharing Started', 'Expiring tracking link sent to trusted contacts', 'HIGH');
        }
        if (d.actionType === 'START_GUARDIAN_VOICE') {
          provider = 'openai-realtime (sandbox)';
          providerResponse = 'Guardian voice channel opened (sandbox audio)';
          guardianSay("Are you able to speak? I'm right here with you.");
        }
        if (d.actionType === 'SEND_SAFETY_CHECK') {
          provider = 'safenet-core';
          providerResponse = 'Safety check presented to user';
          set({ safetyCheck: { sentAtTick: get().tickCount, reason: d.reason, answered: false } });
          guardianSay(guardianProactive('CHECK'));
          log('Safety Check Sent', d.reason, 'MEDIUM');
        }
        if (d.actionType === 'ESCALATE_EMERGENCY_SERVICES') {
          provider = 'twilio-voice (sandbox)';
          const svc = EMERGENCY_SERVICES[0];
          targetLabel = `${svc.label} · ${svc.number} (verified)`;
          providerResponse = 'Twilio sandbox: emergency-service workflow initiated (mock — no real authority contacted)';
          pushFeed('CALL', `Escalation → ${svc.label} (${svc.number})`, 'Sandbox adapter: production adapter would place a verified, policy-controlled call. No real emergency service was contacted.');
          log('Emergency-Service Escalation', `Configured workflow initiated → ${svc.label} (sandbox)`, 'CRITICAL');
        }
        if (d.actionType === 'PUSH_NOTIFICATION') {
          provider = 'firebase-admin (sandbox)';
          providerResponse = 'FCM sandbox: delivered';
        }

        set((s) => ({
          actions: [
            ...s.actions,
            { id: key, sessionId, actionType: d.actionType, target: targetLabel, status: 'EXECUTED', provider, providerResponse, timestamp: Date.now() },
          ],
        }));
      };

      const runPolicy = (explicitSOS: boolean, userUnresponsive: boolean) => {
        const s = get();
        const sessionId = s.emergency?.id ?? 'monitor-' + (s.journey?.id ?? 'none');
        const decisions = evaluatePolicy({
          assessment: s.risk,
          state: s.emergency?.state ?? 'IDLE',
          settings: s.settings,
          contacts: s.contacts,
          explicitSOS,
          userUnresponsive,
        });
        for (const d of decisions) execute(sessionId, d);
        return decisions;
      };

      const ensureSession = (method: ActivationMethod, state: EmergencyState, riskLevel: RiskLevel) => {
        let e = get().emergency;
        if (!e) {
          e = {
            id: `SES-${Math.floor(1000 + Math.random() * 9000)}`,
            activationMethod: method,
            state,
            riskLevel,
            startedAt: Date.now(),
            locationShared: false,
            silent: false,
          };
          set({ emergency: e, timeline: [], actions: [] });
          log('Emergency Session Created', `Activation: ${method}`, riskLevel);
        }
        return e;
      };

      const reassess = (overrides: Partial<Parameters<typeof assessThreat>[0]> = {}) => {
        const s = get();
        const pos = s.position;
        const z = zoneAt(pos);
        const j = s.journey;
        const elapsedMin = j ? (s.tickCount - 0) / JOURNEY_TICKS * j.expectedMinutes : 0;
        const assessment = assessThreat({
          explicitSOS: false,
          routeDeviationMeters: j?.deviated ? j.deviationMeters : 0,
          inHighRiskZone: !!z && z.zone.riskScore >= 50,
          zoneRiskScore: z?.zone.riskScore ?? 0,
          missedCheckIns: j?.missedChecks ?? (s.emergency ? 1 : 0),
          unexpectedStopTicks: j?.stoppedTicks ?? 0,
          journeyOvertimeRatio: j ? elapsedMin / j.expectedMinutes : 1,
          userReportedDanger: false,
          userReportedSafe: false,
          hourOfDay: new Date().getHours(),
          nearbyReportCount: nearbyReports(pos, s.reports),
          ...overrides,
        });
        set({ risk: assessment });
        return assessment;
      };

      const activateEmergency = (method: ActivationMethod, silent = false) => {
        const s = get();
        const e = ensureSession(method, 'EMERGENCY_ACTIVE', 'CRITICAL');
        if (silent) set({ emergency: { ...get().emergency!, silent: true } });
        set({
          risk: {
            riskLevel: 'CRITICAL',
            riskScore: 100,
            confidence: 100,
            reasons: [method === 'SOS_BUTTON' ? 'Explicit SOS activated by user' : method === 'VOICE_TRIGGER' ? 'Voice trigger phrase detected' : 'Silent emergency declared'],
            recommendedAction: 'Activate configured emergency workflow immediately',
            requiresVerification: false,
            timestamp: Date.now(),
          },
        });
        log('Emergency Mode Activated', `Method: ${method}${silent ? ' · silent mode' : ''}`, 'CRITICAL');
        runPolicy(true, true);
        setState('CONTACTS_NOTIFIED', 'Trusted contacts notified per policy');
        if (s.settings.escalateToServices) setState('ESCALATED', 'Configured emergency-service escalation executed (sandbox)');
        guardianSay(guardianProactive('CONTACTS_SENT'), 'SYSTEM');
        return e;
      };

      return {
        user: null,
        contacts: DEMO_CONTACTS,
        reports: SEED_REPORTS,
        settings: {
          autoNotifyContacts: true,
          escalateToServices: false, // opt-in: demo keeps services sandbox-only by default
          shareLocationOnEmergency: true,
          voiceTriggerEnabled: true,
          voicePhrase: 'safenet i need help',
          retentionDays: 30,
        },

        journey: null,
        tickCount: 0,
        position: CITY_CENTER,

        risk: initialRisk,
        emergency: null,
        timeline: [],
        actions: [],
        guardianMessages: [
          { id: 'welcome', from: 'GUARDIAN', text: "I'm your SAFENET Guardian. Start a journey and I'll watch over it — or hold the SOS button any time you need me.", time: Date.now() },
        ],
        safetyCheck: null,
        feed: [],
        scenario: null,
        scenarioTick: 0,

        login: (name) => set({ user: { name } }),
        logout: () => set({ user: null, journey: null, emergency: null, scenario: null }),
        addContact: (c) => set((s) => ({ contacts: [...s.contacts, { ...c, id: nid() }] })),
        removeContact: (id) => set((s) => ({ contacts: s.contacts.filter((c) => c.id !== id) })),
        updateSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),

        startJourney: (originId, destId, routeId) => {
          const route = buildRoutes(originId, destId).find((r) => r.id === routeId)!;
          const origin = getPlace(originId);
          const dest = getPlace(destId);
          const j: Journey = {
            id: nid(),
            originName: origin.name,
            destName: dest.name,
            origin: origin.position,
            destination: dest.position,
            route,
            startedAt: Date.now(),
            expectedMinutes: route.minutes,
            positionIdx: 0,
            deviated: false,
            deviationMeters: 0,
            stoppedTicks: 0,
            missedChecks: 0,
            status: 'ACTIVE',
          };
          set({
            journey: j,
            tickCount: 0,
            position: origin.position,
            timeline: [],
            actions: [],
            emergency: null,
            risk: initialRisk,
            safetyCheck: null,
          });
          log('Journey Started', `${origin.name} → ${dest.name} · ${route.label} (safety ${route.safetyScore})`, 'INFO');
          pushFeed('SYSTEM', 'Journey started', `${origin.name} → ${dest.name}. Guardian is monitoring.`);
          guardianSay(`Journey started. I'm monitoring your route — expected arrival in about ${route.minutes} minutes.`);
          reassess();
        },

        endJourney: (completed) => {
          const j = get().journey;
          if (!j) return;
          set({ journey: { ...j, status: completed ? 'COMPLETED' : 'INTERRUPTED' } });
          log(completed ? 'Journey Completed' : 'Journey Ended Early', `${j.originName} → ${j.destName}`, 'INFO');
          pushFeed('PUSH', completed ? 'Journey completed' : 'Journey ended', `${j.originName} → ${j.destName}`);
          set({ journey: null, risk: initialRisk, safetyCheck: null });
        },

        tick: () => {
          const s = get();
          const active = s.journey?.status === 'ACTIVE' || (s.emergency && s.emergency.state !== 'RESOLVED');
          if (!active) return;
          const t = s.tickCount + 1;
          set({ tickCount: t });

          // ---------- scripted demo scenarios ----------
          if (s.scenario) {
            set({ scenarioTick: s.scenarioTick + 1 });
            const st = s.scenarioTick + 1;
            const j = get().journey;

            const deviate = () => {
              if (!j || j.deviated) return;
              const devPos = offsetPoint(pointAlongPath(j.route.path, Math.min(t / JOURNEY_TICKS, 0.9)), -260, -180);
              set({
                journey: { ...get().journey!, deviated: true, deviationMeters: Math.round(distanceToPath(devPos, j.route.path)) },
                position: devPos,
              });
              log('Route Deviation Detected', `Position moved ~${get().journey!.deviationMeters} m off planned route`, 'MEDIUM');
              guardianSay(guardianProactive('DEVIATION'));
              const a = reassess();
              if (a.riskLevel !== 'LOW') setState('ANOMALY_DETECTED', 'Route deviation signal fused with context');
              runPolicy(false, false);
            };

            switch (s.scenario) {
              case 1: // Route deviation → check → user safe → resume
                if (st === 18) deviate();
                if (st === 33 && get().safetyCheck && !get().safetyCheck.answered) {
                  get().answerSafetyCheck(true);
                  guardianSay('Thank you — resuming quiet monitoring.');
                }
                break;
              case 2: // No response → escalation ladder
                if (st === 12) {
                  ensureSession('SIMULATION', 'MONITORING', 'LOW');
                  deviate();
                }
                // deadline expiry handled in generic logic below
                break;
              case 3: // Silent emergency
                if (st === 8) {
                  guardianSay('Safety check — are you okay?', 'SYSTEM');
                  get().sendUserMessage("I can't talk");
                }
                break;
              case 5: // Critical escalation
                if (st === 10) {
                  ensureSession('SIMULATION', 'MONITORING', 'LOW');
                  deviate();
                }
                break;
              default:
                break;
            }
          }

          // ---------- journey movement ----------
          const j = get().journey;
          if (j && j.status === 'ACTIVE') {
            const frac = Math.min(t / JOURNEY_TICKS, 1);
            let pos = pointAlongPath(j.route.path, frac);
            if (j.deviated) {
              pos = offsetPoint(pos, -260, -180);
              const dm = Math.round(distanceToPath(pos, j.route.path));
              if (Math.abs(dm - j.deviationMeters) > 30) set({ journey: { ...get().journey!, deviationMeters: dm } });
            }
            set({ position: pos });

            // zone entry detection
            const z = zoneAt(pos);
            if (z && z.zone.riskScore >= 50 && !j.deviated) {
              const already = get().timeline.some((e) => e.event === 'High-Risk Zone Entry' && e.time > j.startedAt);
              if (!already) {
                log('High-Risk Zone Entry', `${z.zone.name} · zone risk ${z.zone.riskScore}/100`, 'MEDIUM');
                reassess();
                runPolicy(false, false);
              }
            }

            if (frac >= 1) {
              get().endJourney(true);
              return;
            }
          }

          // ---------- safety check deadline ----------
          const check = get().safetyCheck;
          if (check && !check.answered && t - check.sentAtTick >= CHECK_DEADLINE_TICKS) {
            set({ safetyCheck: null });
            const jj = get().journey;
            if (jj) set({ journey: { ...jj, missedChecks: jj.missedChecks + 1 } });
            log('No Response', 'Safety check window expired with no answer', 'HIGH');
            ensureSession('ANOMALY', 'WARNING', 'HIGH');
            const a = reassess();
            log(`Risk Increased: ${a.riskLevel}`, a.reasons.join(' · '), a.riskLevel);
            setState('WARNING', 'User unresponsive — escalating per ladder');
            runPolicy(false, true);
            setState('CONTACTS_NOTIFIED', 'Trusted contacts alerted; live location shared');
            guardianSay(guardianProactive('RISK_UP'));

            // Scenario 5 continues: simulated user reports being followed
            if (get().scenario === 5) {
              setTimeout(() => get().sendUserMessage('Someone is following me'), 2500);
            }
          }

          // ---------- continuous reassessment ----------
          if (get().journey?.status === 'ACTIVE' || get().emergency) reassess();
        },

        triggerSOS: (method) => {
          activateEmergency(method);
        },

        answerSafetyCheck: (safe) => {
          const check = get().safetyCheck;
          if (check) set({ safetyCheck: { ...check, answered: true } });
          if (safe) {
            log('User Confirmed Safe', 'Safety check answered — resuming monitoring', 'LOW');
            const j = get().journey;
            if (j) set({ journey: { ...j, deviated: false, deviationMeters: 0 } });
            set({ risk: { ...initialRisk, timestamp: Date.now() } });
            const e = get().emergency;
            if (e && e.state !== 'RESOLVED' && e.activationMethod === 'ANOMALY') {
              set({ emergency: { ...e, state: 'RESOLVED', endedAt: Date.now() } });
              log('State → RESOLVED', 'User confirmed safety', 'LOW');
            }
            guardianSay("Glad you're safe. I'll keep watching quietly.");
          } else {
            log('User Requested Help', 'Safety check answered: NOT safe', 'CRITICAL');
            activateEmergency('ANOMALY');
          }
          set({ safetyCheck: null });
        },

        sendUserMessage: (text) => {
          set((s) => ({ guardianMessages: [...s.guardianMessages, { id: nid(), from: 'USER', text, time: Date.now() }] }));
          const s = get();
          const result = guardianRespond(text, !!s.emergency, s.settings.voiceTriggerEnabled ? s.settings.voicePhrase : '');

          if (result.intent === 'TRIGGER_PHRASE') {
            guardianSay(result.reply);
            activateEmergency('VOICE_TRIGGER');
            return;
          }
          if (result.intent === 'SAFE') {
            guardianSay(result.reply);
            get().answerSafetyCheck(true);
            return;
          }
          if (result.intent === 'CANT_TALK') {
            guardianSay(result.reply);
            log('Silent Emergency Declared', 'User unable to speak — silent protocol', 'CRITICAL');
            activateEmergency('SIMULATION', true);
            return;
          }
          if (result.userReportedDanger) {
            guardianSay(result.reply);
            const e = ensureSession('SIMULATION', 'EMERGENCY_ACTIVE', 'CRITICAL');
            void e;
            set({
              risk: {
                riskLevel: 'CRITICAL',
                riskScore: 96,
                confidence: 93,
                reasons: [...get().risk.reasons.filter((r) => r !== 'No active threat signals'), 'User reported danger to AI Guardian'],
                recommendedAction: 'Escalate per configured policy',
                requiresVerification: false,
                timestamp: Date.now(),
              },
            });
            log('User Reported Danger', `"${text}"`, 'CRITICAL');
            runPolicy(false, true);
            setState('CONTACTS_NOTIFIED', 'Contacts notified; location live');
            guardianSay(guardianProactive('SAFE_PLACE'));
            return;
          }
          if (result.intent === 'CALL_CONTACT') {
            guardianSay(result.reply);
            get().callForHelp();
            return;
          }
          guardianSay(result.reply);
        },

        callForHelp: () => {
          const s = get();
          const e = s.emergency ?? activateEmergency('SOS_BUTTON');
          const priority = s.contacts.filter((c) => c.callEnabled).sort((a, b) => a.priority - b.priority)[0];
          if (priority) {
            execute(e.id, { actionType: 'PLACE_CALL', target: priority.id, reason: 'User tapped CALL FOR HELP' });
            log('Outbound Call Placed', `Priority contact: ${priority.name} (sandbox)`, 'CRITICAL');
          }
          if (s.settings.escalateToServices) {
            execute(e.id, { actionType: 'ESCALATE_EMERGENCY_SERVICES', target: 'EMERGENCY_SERVICES', reason: 'User tapped CALL FOR HELP; policy permits' });
          }
        },

        resolveEmergency: () => {
          const e = get().emergency;
          if (!e) return;
          set({ emergency: { ...e, state: 'RESOLVED', endedAt: Date.now() } });
          log('Emergency Resolved', 'User tapped I\'M SAFE — session closed, tracking link expired', 'LOW');
          pushFeed('PUSH', 'Emergency resolved', 'Your trusted contacts have been notified that you are safe.');
          guardianSay('Emergency resolved. Glad you\'re safe — take a moment. I\'m here whenever you need me.', 'SYSTEM');
          set({ risk: { ...initialRisk, timestamp: Date.now() }, journey: null, scenario: null, safetyCheck: null });
          setTimeout(() => set({ emergency: null, timeline: [], actions: [] }), 4000);
        },

        submitReport: (description, hasPhoto, position) => {
          const analysis = analyzeReport(description, hasPhoto);
          const report: SafetyReport = {
            id: nid(),
            author: get().user?.name ?? 'You',
            category: analysis.category,
            description,
            position,
            severity: analysis.severity,
            confidence: analysis.confidence,
            aiSummary: analysis.aiSummary,
            hasPhoto,
            status: 'PENDING',
            createdAt: Date.now(),
          };
          set((s) => ({ reports: [report, ...s.reports] }));
          pushFeed('SYSTEM', 'Safety report submitted', `${analysis.category} · ${analysis.severity} · ${analysis.confidence}% confidence`);
          return report;
        },

        runScenario: (n) => {
          get().resetDemo();
          if (n === 4) {
            log('Demo Scenario 4', 'Explicit SOS simulation', 'CRITICAL');
            activateEmergency('SIMULATION');
            return;
          }
          // scenarios 1,2,3,5 begin with a journey College → Home on the safe route
          get().startJourney('college', 'home', 'safest');
          set({ scenario: n, scenarioTick: 0 });
          log(`Demo Scenario ${n} Started`, ['', 'Route deviation', 'No response', 'Silent emergency', 'Explicit SOS', 'Critical escalation'][n], 'INFO');
        },

        resetDemo: () => {
          set({
            journey: null,
            emergency: null,
            scenario: null,
            scenarioTick: 0,
            tickCount: 0,
            safetyCheck: null,
            risk: initialRisk,
            position: CITY_CENTER,
          });
        },
      };
    },
    {
      name: 'safenet-store',
      partialize: (s) => ({ user: s.user, contacts: s.contacts, reports: s.reports, settings: s.settings }),
    },
  ),
);

// ---------- derived helpers ----------
export function useSafetyScore(): number {
  return useSafeNet((s) => {
    const z = zoneAt(s.position);
    const zonePenalty = z ? z.zone.riskScore * 0.35 : 0;
    const riskPenalty = s.risk.riskScore * 0.55;
    return Math.max(2, Math.min(99, Math.round(96 - zonePenalty - riskPenalty)));
  });
}

export function useNearestSafePlaces(limit = 3) {
  return useSafeNet((s) => {
    return SAFE_PLACES.map((p) => ({ ...p, distanceMeters: haversineMeters(s.position, p.position) }))
      .sort((a, b) => a.distanceMeters - b.distanceMeters)
      .slice(0, limit);
  });
}

export { SAFETY_ZONES, SAFE_PLACES, SEED_REPORTS, EMERGENCY_SERVICES, CITY_CENTER, buildRoutes, getPlace, PLACES };
