import type { LatLng } from './types';

export function haversineMeters(a: LatLng, b: LatLng): number {
  const R = 6371000;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const la1 = (a.lat * Math.PI) / 180;
  const la2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

export function formatDistance(meters: number): string {
  if (meters < 1000) return `${Math.round(meters)} m`;
  return `${(meters / 1000).toFixed(1)} km`;
}

// Interpolate a point along a polyline by fraction 0..1
export function pointAlongPath(path: LatLng[], fraction: number): LatLng {
  if (path.length === 0) return { lat: 0, lng: 0 };
  if (path.length === 1) return path[0];
  const segLengths: number[] = [];
  let total = 0;
  for (let i = 0; i < path.length - 1; i++) {
    const d = haversineMeters(path[i], path[i + 1]);
    segLengths.push(d);
    total += d;
  }
  let target = Math.min(Math.max(fraction, 0), 1) * total;
  for (let i = 0; i < segLengths.length; i++) {
    if (target <= segLengths[i]) {
      const t = segLengths[i] === 0 ? 0 : target / segLengths[i];
      return {
        lat: path[i].lat + (path[i + 1].lat - path[i].lat) * t,
        lng: path[i].lng + (path[i + 1].lng - path[i].lng) * t,
      };
    }
    target -= segLengths[i];
  }
  return path[path.length - 1];
}

export function pathLengthMeters(path: LatLng[]): number {
  let total = 0;
  for (let i = 0; i < path.length - 1; i++) total += haversineMeters(path[i], path[i + 1]);
  return total;
}

// Approx distance from point to polyline
export function distanceToPath(p: LatLng, path: LatLng[]): number {
  let min = Infinity;
  const samples = 60;
  for (let i = 0; i <= samples; i++) {
    const q = pointAlongPath(path, i / samples);
    min = Math.min(min, haversineMeters(p, q));
  }
  return min;
}

export function offsetPoint(p: LatLng, northMeters: number, eastMeters: number): LatLng {
  const dLat = northMeters / 111320;
  const dLng = eastMeters / (111320 * Math.cos((p.lat * Math.PI) / 180));
  return { lat: p.lat + dLat, lng: p.lng + dLng };
}

export function etaString(minutesFromNow: number): string {
  const d = new Date(Date.now() + minutesFromNow * 60000);
  return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

export function fmtClock(ts: number): string {
  return new Date(ts).toLocaleTimeString([], { hour12: false });
}
