import type { RiskAssessment, RiskLevel, ThreatContext } from './types';

/**
 * ThreatAssessmentEngine — multi-signal contextual fusion.
 * Explicitly designed so that ONE weak signal never escalates to emergency
 * (false-positive protection), while explicit SOS always wins.
 */
export function assessThreat(ctx: ThreatContext): RiskAssessment {
  // Explicit SOS bypasses fusion: immediate CRITICAL
  if (ctx.explicitSOS) {
    return {
      riskLevel: 'CRITICAL',
      riskScore: 100,
      confidence: 100,
      reasons: ['Explicit SOS activated by user'],
      recommendedAction: 'Activate configured emergency workflow immediately',
      requiresVerification: false,
      timestamp: Date.now(),
    };
  }

  let score = 0;
  const reasons: string[] = [];
  let signals = 0;

  // Signal: route deviation
  if (ctx.routeDeviationMeters > 150) {
    score += 22;
    signals++;
    reasons.push(`Significant route deviation (${Math.round(ctx.routeDeviationMeters)} m off planned path)`);
  }

  // Signal: high-risk zone
  if (ctx.inHighRiskZone) {
    score += Math.round(ctx.zoneRiskScore * 0.28);
    signals++;
    reasons.push(`Entered elevated-risk zone (zone risk ${ctx.zoneRiskScore}/100)`);
  }

  // Signal: missed safety check-ins
  if (ctx.missedCheckIns > 0) {
    score += ctx.missedCheckIns * 24;
    signals += ctx.missedCheckIns;
    reasons.push(ctx.missedCheckIns === 1 ? 'Safety check unanswered' : `${ctx.missedCheckIns} safety checks unanswered`);
  }

  // Signal: unexpected prolonged stop
  if (ctx.unexpectedStopTicks >= 5) {
    score += 18;
    signals++;
    reasons.push('Unexpected prolonged stop detected');
  }

  // Signal: journey significantly over expected duration
  if (ctx.journeyOvertimeRatio > 1.4) {
    score += 12;
    signals++;
    reasons.push('Journey duration significantly above expected');
  }

  // Signal: user explicitly reported danger via Guardian
  if (ctx.userReportedDanger) {
    score += 55;
    signals += 2;
    reasons.push('User reported danger to AI Guardian');
  }

  // Modulator: night time amplifies existing risk
  const night = ctx.hourOfDay >= 21 || ctx.hourOfDay < 5;
  if (night && score > 0) {
    score = Math.round(score * 1.15);
    reasons.push('Late-night hours increase contextual risk');
  }

  // Modulator: cluster of community reports nearby
  if (ctx.nearbyReportCount >= 2) {
    score += 8;
    reasons.push(`${ctx.nearbyReportCount} recent community safety reports nearby`);
  }

  // User confirmed safe damps everything
  if (ctx.userReportedSafe) {
    score = Math.min(score, 15);
  }

  score = Math.min(100, score);

  let riskLevel: RiskLevel = 'LOW';
  if (score >= 75) riskLevel = 'CRITICAL';
  else if (score >= 50) riskLevel = 'HIGH';
  else if (score >= 25) riskLevel = 'MEDIUM';

  // Confidence rises with the number of corroborating signals
  const confidence = Math.min(98, 40 + signals * 18);

  let recommendedAction = 'Continue monitoring';
  if (riskLevel === 'MEDIUM') recommendedAction = 'Send safety check to user';
  if (riskLevel === 'HIGH') recommendedAction = 'Verify user safety; prepare trusted-contact alert';
  if (riskLevel === 'CRITICAL') recommendedAction = 'Escalate per configured policy';

  // Verification required unless the user themselves reported danger
  const requiresVerification = riskLevel !== 'LOW' && !ctx.userReportedDanger;

  return {
    riskLevel,
    riskScore: score,
    confidence,
    reasons: reasons.length ? reasons : ['No active threat signals'],
    recommendedAction,
    requiresVerification,
    timestamp: Date.now(),
  };
}

export const RISK_COLORS: Record<RiskLevel, string> = {
  LOW: '#22c55e',
  MEDIUM: '#eab308',
  HIGH: '#f97316',
  CRITICAL: '#ef4444',
};
