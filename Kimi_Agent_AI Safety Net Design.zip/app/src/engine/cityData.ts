import type { LatLng, RouteOption, SafePlace, SafetyReport, SafetyZone } from './types';

// Demo city: modelled on central New Delhi (Connaught Place area)
export const CITY_CENTER: LatLng = { lat: 28.6315, lng: 77.2167 };

export interface Place {
  id: string;
  name: string;
  position: LatLng;
}

export const PLACES: Place[] = [
  { id: 'college', name: 'City College', position: { lat: 28.628, lng: 77.2065 } },
  { id: 'home', name: 'Home — Karol Bagh', position: { lat: 28.6519, lng: 77.1907 } },
  { id: 'hostel', name: 'Green Park Hostel', position: { lat: 28.6128, lng: 77.2273 } },
  { id: 'metro', name: 'Rajiv Chowk Metro', position: { lat: 28.6328, lng: 77.2197 } },
  { id: 'office', name: 'Nehru Place Office', position: { lat: 28.6448, lng: 77.216 } },
  { id: 'market', name: 'Connaught Market', position: { lat: 28.6315, lng: 77.2167 } },
];

export function getPlace(id: string): Place {
  return PLACES.find((p) => p.id === id) ?? PLACES[0];
}

function pathBetween(a: LatLng, b: LatLng, via: LatLng[] = []): LatLng[] {
  return [a, ...via, b];
}

export function buildRoutes(originId: string, destId: string): RouteOption[] {
  const o = getPlace(originId).position;
  const d = getPlace(destId).position;
  const midLat = (o.lat + d.lat) / 2;
  const midLng = (o.lng + d.lng) / 2;

  const fastestPath = pathBetween(o, d, [
    { lat: o.lat + (midLat - o.lat) * 0.4 + 0.0012, lng: o.lng + (midLng - o.lng) * 0.35 - 0.0018 },
    { lat: midLat - 0.0008, lng: midLng - 0.0022 }, // cuts through the dark belt
    { lat: d.lat + (midLat - d.lat) * 0.5, lng: d.lng + (midLng - d.lng) * 0.6 - 0.001 },
  ]);

  const safePath = pathBetween(o, d, [
    { lat: o.lat + 0.0015, lng: o.lng + 0.0045 },
    { lat: midLat + 0.0022, lng: midLng + 0.0055 }, // main road, lit, near metro
    { lat: midLat + 0.003, lng: midLng + 0.001 },
    { lat: d.lat - 0.001, lng: d.lng + 0.0035 },
  ]);

  return [
    {
      id: 'fastest',
      label: 'Fastest Route',
      kind: 'FASTEST',
      path: fastestPath,
      minutes: 9,
      distanceKm: 2.6,
      safetyScore: 62,
      explanation:
        'Shortest path, but crosses an elevated-risk zone with poor lighting and 3 recent community reports.',
    },
    {
      id: 'safest',
      label: 'Recommended Safe Route',
      kind: 'SAFEST',
      path: safePath,
      minutes: 12,
      distanceKm: 3.1,
      safetyScore: 91,
      explanation:
        'Recommended: stays on well-lit main roads, passes 2 verified safe places, avoids all high-risk zones.',
    },
  ];
}

export const SAFETY_ZONES: SafetyZone[] = [
  {
    id: 'z1',
    name: 'Old Warehouse Belt',
    center: { lat: 28.6395, lng: 77.1995 },
    radiusMeters: 420,
    riskScore: 82,
    incidentCount: 14,
    category: 'Poor lighting / harassment reports',
  },
  {
    id: 'z2',
    name: 'Canal Road Stretch',
    center: { lat: 28.6205, lng: 77.2095 },
    radiusMeters: 350,
    riskScore: 64,
    incidentCount: 8,
    category: 'Isolated stretch at night',
  },
  {
    id: 'z3',
    name: 'Station Back Exit',
    center: { lat: 28.6442, lng: 77.2205 },
    radiusMeters: 300,
    riskScore: 55,
    incidentCount: 6,
    category: 'Crowd density / snatching reports',
  },
  {
    id: 'z4',
    name: 'Central Market District',
    center: { lat: 28.6315, lng: 77.2167 },
    radiusMeters: 500,
    riskScore: 18,
    incidentCount: 1,
    category: 'Well-lit, patrolled',
  },
  {
    id: 'z5',
    name: 'University Campus Ring',
    center: { lat: 28.627, lng: 77.2075 },
    radiusMeters: 380,
    riskScore: 25,
    incidentCount: 2,
    category: 'CCTV covered, security posts',
  },
];

export const SAFE_PLACES: SafePlace[] = [
  {
    id: 'sp1',
    name: 'Connaught Place Police Station',
    category: 'POLICE',
    position: { lat: 28.6335, lng: 77.221 },
    open24h: true,
    verified: true,
  },
  {
    id: 'sp2',
    name: 'City General Hospital (24×7 ER)',
    category: 'HOSPITAL',
    position: { lat: 28.639, lng: 77.208 },
    open24h: true,
    verified: true,
  },
  {
    id: 'sp3',
    name: 'Rajiv Chowk Metro — Gate 4',
    category: 'TRANSIT',
    position: { lat: 28.6328, lng: 77.2197 },
    open24h: false,
    verified: true,
  },
  {
    id: 'sp4',
    name: 'All-Night Pharmacy & Cafe',
    category: 'PHARMACY',
    position: { lat: 28.6355, lng: 77.2115 },
    open24h: true,
    verified: true,
  },
  {
    id: 'sp5',
    name: 'Karol Bagh Police Post',
    category: 'POLICE',
    position: { lat: 28.6505, lng: 77.1925 },
    open24h: true,
    verified: true,
  },
  {
    id: 'sp6',
    name: 'Campus Security Kiosk',
    category: 'PUBLIC',
    position: { lat: 28.6285, lng: 77.206 },
    open24h: true,
    verified: true,
  },
];

export const SEED_REPORTS: SafetyReport[] = [
  {
    id: 'r1',
    author: 'Community member',
    category: 'Broken Streetlight',
    description: 'Three streetlights out near the warehouse lane, pitch dark after 8pm.',
    position: { lat: 28.64, lng: 77.2005 },
    severity: 'HIGH',
    confidence: 94,
    aiSummary: 'Poor lighting may reduce visibility on this road and increase vulnerability at night.',
    hasPhoto: true,
    status: 'VERIFIED',
    createdAt: Date.now() - 86400000 * 2,
  },
  {
    id: 'r2',
    author: 'Community member',
    category: 'Harassment Hotspot',
    description: 'Group loitering near canal road underpass, catcalling reported twice this week.',
    position: { lat: 28.621, lng: 77.2102 },
    severity: 'HIGH',
    confidence: 88,
    aiSummary: 'Repeated harassment reports indicate an emerging risk pattern in this area after dark.',
    hasPhoto: false,
    status: 'VERIFIED',
    createdAt: Date.now() - 86400000 * 4,
  },
  {
    id: 'r3',
    author: 'Community member',
    category: 'Unsafe Crossing',
    description: 'No zebra crossing or signal at the station back exit, heavy fast traffic.',
    position: { lat: 28.6445, lng: 77.22 },
    severity: 'MEDIUM',
    confidence: 81,
    aiSummary: 'Uncontrolled crossing with fast-moving traffic poses elevated pedestrian risk.',
    hasPhoto: true,
    status: 'VERIFIED',
    createdAt: Date.now() - 86400000 * 6,
  },
];

export const DEMO_CONTACTS = [
  {
    id: 'c1',
    name: 'Mom (Demo)',
    phone: '+91-90000-00001',
    relationship: 'Family',
    priority: 1,
    notificationEnabled: true,
    callEnabled: true,
  },
  {
    id: 'c2',
    name: 'Riya — Roommate (Demo)',
    phone: '+91-90000-00002',
    relationship: 'Roommate',
    priority: 2,
    notificationEnabled: true,
    callEnabled: true,
  },
  {
    id: 'c3',
    name: 'Arjun — Brother (Demo)',
    phone: '+91-90000-00003',
    relationship: 'Family',
    priority: 3,
    notificationEnabled: true,
    callEnabled: false,
  },
];

export const EMERGENCY_SERVICES = [
  { id: 'es1', label: 'Police Control Room', number: '112', verified: true },
  { id: 'es2', label: 'Women Helpline', number: '1091', verified: true },
  { id: 'es3', label: 'Ambulance', number: '102', verified: true },
];
