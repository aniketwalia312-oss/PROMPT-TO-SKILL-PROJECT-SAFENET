import type { RiskLevel } from './types';

export interface ReportAnalysis {
  category: string;
  severity: RiskLevel;
  confidence: number;
  aiSummary: string;
}

const RULES: { category: string; keywords: RegExp; severity: RiskLevel; summary: string }[] = [
  {
    category: 'Broken Streetlight',
    keywords: /light|lamp|dark|bulb|streetlight/,
    severity: 'HIGH',
    summary: 'Poor lighting reduces visibility and increases vulnerability in this area, especially after dark.',
  },
  {
    category: 'Harassment Hotspot',
    keywords: /harass|catcall|loiter|follow|eve.?teas|stare|grope|molest/,
    severity: 'HIGH',
    summary: 'Behavioural reports indicate a potential harassment pattern; recommend increased caution and patrol presence.',
  },
  {
    category: 'Unsafe Crossing',
    keywords: /cross|zebra|traffic|signal|road|rvehicles|speed/,
    severity: 'MEDIUM',
    summary: 'Uncontrolled or fast-moving traffic creates elevated pedestrian risk at this crossing.',
  },
  {
    category: 'Suspicious Activity',
    keywords: /suspicious|strange|unknown|watching|drug|fight|weapon/,
    severity: 'HIGH',
    summary: 'Suspicious activity reported; situational awareness advised and authorities may be informed if it persists.',
  },
  {
    category: 'Broken Infrastructure',
    keywords: /broken|pothole|construction|debris|open drain|damaged/,
    severity: 'MEDIUM',
    summary: 'Damaged infrastructure may cause accidents, particularly in low-visibility conditions.',
  },
  {
    category: 'Isolated Area',
    keywords: /isolated|deserted|empty|alone|no people|abandoned/,
    severity: 'MEDIUM',
    summary: 'Low footfall makes this area feel unsafe at night; buddy travel or alternate routes are advisable.',
  },
];

/** Simulated multimodal analysis — deterministic classifier with the same
 *  interface a vision/LLM-backed service would implement server-side. */
export function analyzeReport(description: string, hasPhoto: boolean): ReportAnalysis {
  const text = description.toLowerCase();
  for (const rule of RULES) {
    if (rule.keywords.test(text)) {
      const confidence = Math.min(97, 72 + (hasPhoto ? 12 : 0) + Math.floor(text.length / 12));
      return { category: rule.category, severity: rule.severity, confidence, aiSummary: rule.summary };
    }
  }
  return {
    category: 'General Safety Concern',
    severity: 'LOW',
    confidence: 64,
    aiSummary: 'General concern logged; will be correlated with nearby reports to detect emerging patterns.',
  };
}
