import "dotenv/config";
import { getDb } from "../api/queries/connection";
import { safetyZones, safePlaces, safetyReports, users } from "./schema";
import { eq } from "drizzle-orm";

// Demo geography: "Greenfield" campus district (internally consistent grid)
// Center ≈ 12.9352, 77.6245

async function seed() {
  const db = getDb();

  const zones = await db.select().from(safetyZones).limit(1);
  if (zones.length > 0) {
    console.log("Already seeded, skipping.");
    return;
  }

  await db.insert(safetyZones).values([
    { label: "Old Market Road", centerLat: 12.9385, centerLng: 77.6205, radiusM: 260, riskScore: 78, incidentCount: 14, category: "harassment_reports" },
    { label: "Riverfront Underpass", centerLat: 12.9312, centerLng: 77.629, radiusM: 200, riskScore: 84, incidentCount: 19, category: "poor_lighting" },
    { label: "North Gate Parking", centerLat: 12.9401, centerLng: 77.6268, radiusM: 180, riskScore: 55, incidentCount: 7, category: "theft" },
    { label: "Lakeview Trail", centerLat: 12.9285, centerLng: 77.6215, radiusM: 300, riskScore: 41, incidentCount: 4, category: "isolated_area" },
    { label: "Central Square", centerLat: 12.9355, centerLng: 77.624, radiusM: 220, riskScore: 12, incidentCount: 1, category: "well_lit_crowded" },
    { label: "Hostel Block C Surround", centerLat: 12.9332, centerLng: 77.6262, radiusM: 150, riskScore: 22, incidentCount: 2, category: "patrolled" },
  ]);

  await db.insert(safePlaces).values([
    { name: "Greenfield Police Post", category: "police", latitude: 12.9368, longitude: 77.6232, open24h: true, verified: true },
    { name: "St. Mary's Hospital ER", category: "hospital", latitude: 12.9395, longitude: 77.628, open24h: true, verified: true },
    { name: "Metro Station — North Gate", category: "transit_hub", latitude: 12.9408, longitude: 77.6255, open24h: false, verified: true },
    { name: "Campus Security Office", category: "public_safety_point", latitude: 12.9348, longitude: 77.6248, open24h: true, verified: true },
    { name: "24x7 Pharmacy & Convenience", category: "pharmacy", latitude: 12.9338, longitude: 77.6225, open24h: true, verified: true },
    { name: "Late-Night Café (open till 2am)", category: "open_business", latitude: 12.936, longitude: 77.626, open24h: false, verified: false },
    { name: "Bus Depot — Central Square", category: "transit_hub", latitude: 12.9352, longitude: 77.6238, open24h: true, verified: true },
  ]);

  // seed a demo user for community reports
  const [existing] = await db.select().from(users).limit(1);
  let uid = existing?.id;
  if (!uid) {
    const [{ id }] = await db
      .insert(users)
      .values({ unionId: "demo-seed-user", name: "Community Member" })
      .$returningId();
    uid = id;
  }

  await db.insert(safetyReports).values([
    { userId: uid, category: "Broken Streetlight", description: "Three consecutive streetlights out near the underpass. Pitch black after 8pm.", latitude: 12.9314, longitude: 77.6288, locationLabel: "Riverfront Underpass", severity: "HIGH", confidence: 0.94, status: "confirmed", confirmations: 6, aiAnalysis: { summary: "Poor lighting may reduce visibility on this stretch.", factors: ["nighttime risk", "pedestrian route"] } },
    { userId: uid, category: "Harassment Report", description: "Group loitering near the market entrance, catcalling pedestrians.", latitude: 12.9383, longitude: 77.6202, locationLabel: "Old Market Road", severity: "HIGH", confidence: 0.88, status: "confirmed", confirmations: 4, aiAnalysis: { summary: "Repeated harassment pattern reported at this location." } },
    { userId: uid, category: "Unsafe Crossing", description: "No signal, fast traffic. Students cross here daily.", latitude: 12.9362, longitude: 77.6272, locationLabel: "College Main Road", severity: "MEDIUM", confidence: 0.91, status: "confirmed", confirmations: 9, aiAnalysis: { summary: "Uncontrolled crossing on a high-speed road." } },
    { userId: uid, category: "Suspicious Activity", description: "Person following pedestrians near the lake trail after dark.", latitude: 12.9286, longitude: 77.6218, locationLabel: "Lakeview Trail", severity: "MEDIUM", confidence: 0.72, status: "confirmed", confirmations: 2, aiAnalysis: { summary: "Isolated area with low foot traffic after sunset." } },
    { userId: uid, category: "Broken Streetlight", description: "Flickering light at parking lot entrance.", latitude: 12.94, longitude: 77.6266, locationLabel: "North Gate Parking", severity: "LOW", confidence: 0.9, status: "confirmed", confirmations: 3, aiAnalysis: { summary: "Partial lighting failure, visibility reduced." } },
    { userId: uid, category: "Stray Dogs", description: "Aggressive pack near the back gate in early mornings.", latitude: 12.9328, longitude: 77.6235, locationLabel: "Back Gate Lane", severity: "MEDIUM", confidence: 0.85, status: "confirmed", confirmations: 5, aiAnalysis: { summary: "Animal-related risk during low-activity hours." } },
  ]);

  console.log("Seed complete.");
}

seed().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); });
