import {
  mysqlTable,
  mysqlEnum,
  serial,
  bigint,
  varchar,
  text,
  int,
  double,
  boolean,
  timestamp,
  json,
  index,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  profileType: varchar("profileType", { length: 64 }).default("general"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ── Trusted contacts ─────────────────────────────────────────────
export const trustedContacts = mysqlTable(
  "trusted_contacts",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
    name: varchar("name", { length: 255 }).notNull(),
    phone: varchar("phone", { length: 32 }).notNull(),
    email: varchar("email", { length: 320 }),
    relationship: varchar("relationship", { length: 64 }),
    priority: int("priority").default(1).notNull(),
    notificationEnabled: boolean("notificationEnabled").default(true).notNull(),
    callEnabled: boolean("callEnabled").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => ({ userIdx: index("tc_user_idx").on(t.userId) }),
);
export type TrustedContact = typeof trustedContacts.$inferSelect;

// ── Journeys ─────────────────────────────────────────────────────
export const journeys = mysqlTable(
  "journeys",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
    origin: varchar("origin", { length: 255 }).notNull(),
    destination: varchar("destination", { length: 255 }).notNull(),
    originLat: double("originLat").notNull(),
    originLng: double("originLng").notNull(),
    destLat: double("destLat").notNull(),
    destLng: double("destLng").notNull(),
    routeId: varchar("routeId", { length: 64 }),
    plannedRoute: json("plannedRoute"), // array of [lat,lng] waypoints
    routeSafetyScore: int("routeSafetyScore"),
    startedAt: timestamp("startedAt").defaultNow().notNull(),
    expectedArrival: timestamp("expectedArrival"),
    actualArrival: timestamp("actualArrival"),
    status: mysqlEnum("status", ["active", "completed", "cancelled", "emergency"])
      .default("active")
      .notNull(),
  },
  (t) => ({ userIdx: index("j_user_idx").on(t.userId) }),
);
export type Journey = typeof journeys.$inferSelect;

// ── Location points ──────────────────────────────────────────────
export const locationPoints = mysqlTable(
  "location_points",
  {
    id: serial("id").primaryKey(),
    journeyId: bigint("journeyId", { mode: "number", unsigned: true }).notNull(),
    latitude: double("latitude").notNull(),
    longitude: double("longitude").notNull(),
    accuracy: double("accuracy"),
    speed: double("speed"),
    heading: double("heading"),
    timestamp: timestamp("timestamp").defaultNow().notNull(),
  },
  (t) => ({ journeyIdx: index("lp_journey_idx").on(t.journeyId) }),
);
export type LocationPoint = typeof locationPoints.$inferSelect;

// ── Safety events (anomalies, signals) ───────────────────────────
export const safetyEvents = mysqlTable(
  "safety_events",
  {
    id: serial("id").primaryKey(),
    journeyId: bigint("journeyId", { mode: "number", unsigned: true }),
    sessionId: bigint("sessionId", { mode: "number", unsigned: true }),
    eventType: varchar("eventType", { length: 64 }).notNull(),
    severity: mysqlEnum("severity", ["LOW", "MEDIUM", "HIGH", "CRITICAL"]).notNull(),
    confidence: double("confidence"),
    latitude: double("latitude"),
    longitude: double("longitude"),
    metadata: json("metadata"),
    timestamp: timestamp("timestamp").defaultNow().notNull(),
  },
  (t) => ({ journeyIdx: index("se_journey_idx").on(t.journeyId) }),
);
export type SafetyEvent = typeof safetyEvents.$inferSelect;

// ── Community safety reports ─────────────────────────────────────
export const safetyReports = mysqlTable(
  "safety_reports",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
    category: varchar("category", { length: 64 }).notNull(),
    description: text("description"),
    latitude: double("latitude").notNull(),
    longitude: double("longitude").notNull(),
    locationLabel: varchar("locationLabel", { length: 255 }),
    aiAnalysis: json("aiAnalysis"),
    severity: mysqlEnum("severity", ["LOW", "MEDIUM", "HIGH", "CRITICAL"]).notNull(),
    confidence: double("confidence"),
    status: mysqlEnum("status", ["pending", "confirmed", "resolved", "dismissed"])
      .default("confirmed")
      .notNull(),
    confirmations: int("confirmations").default(1).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => ({ userIdx: index("sr_user_idx").on(t.userId) }),
);
export type SafetyReport = typeof safetyReports.$inferSelect;

// ── Safety zones (community-derived risk areas) ──────────────────
export const safetyZones = mysqlTable("safety_zones", {
  id: serial("id").primaryKey(),
  label: varchar("label", { length: 255 }).notNull(),
  centerLat: double("centerLat").notNull(),
  centerLng: double("centerLng").notNull(),
  radiusM: double("radiusM").notNull(),
  riskScore: int("riskScore").notNull(), // 0-100 (100 = most dangerous)
  incidentCount: int("incidentCount").default(0).notNull(),
  category: varchar("category", { length: 64 }),
  lastUpdated: timestamp("lastUpdated").defaultNow().notNull(),
});
export type SafetyZone = typeof safetyZones.$inferSelect;

// ── Safe places ──────────────────────────────────────────────────
export const safePlaces = mysqlTable("safe_places", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: mysqlEnum("category", [
    "police",
    "hospital",
    "transit_hub",
    "public_safety_point",
    "open_business",
    "pharmacy",
  ]).notNull(),
  latitude: double("latitude").notNull(),
  longitude: double("longitude").notNull(),
  open24h: boolean("open24h").default(false).notNull(),
  verified: boolean("verified").default(false).notNull(),
});
export type SafePlace = typeof safePlaces.$inferSelect;

// ── Emergency sessions ───────────────────────────────────────────
export const emergencySessions = mysqlTable(
  "emergency_sessions",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
    journeyId: bigint("journeyId", { mode: "number", unsigned: true }),
    activationMethod: mysqlEnum("activationMethod", [
      "sos_button",
      "voice_trigger",
      "discreet_trigger",
      "auto_anomaly",
      "demo",
    ]).notNull(),
    riskLevel: mysqlEnum("riskLevel", ["LOW", "MEDIUM", "HIGH", "CRITICAL"])
      .default("HIGH")
      .notNull(),
    state: varchar("state", { length: 32 }).default("EMERGENCY_ACTIVE").notNull(),
    shareToken: varchar("shareToken", { length: 64 }).notNull().unique(),
    lastLat: double("lastLat"),
    lastLng: double("lastLng"),
    startedAt: timestamp("startedAt").defaultNow().notNull(),
    endedAt: timestamp("endedAt"),
    status: mysqlEnum("status", ["active", "resolved", "cancelled"])
      .default("active")
      .notNull(),
  },
  (t) => ({ userIdx: index("es_user_idx").on(t.userId) }),
);
export type EmergencySession = typeof emergencySessions.$inferSelect;

// ── Emergency actions (idempotent, auditable) ────────────────────
export const emergencyActions = mysqlTable(
  "emergency_actions",
  {
    id: serial("id").primaryKey(),
    sessionId: bigint("sessionId", { mode: "number", unsigned: true }).notNull(),
    actionType: varchar("actionType", { length: 64 }).notNull(),
    target: varchar("target", { length: 255 }).notNull(),
    status: mysqlEnum("status", ["pending", "executed", "failed", "skipped"])
      .default("executed")
      .notNull(),
    providerResponse: text("providerResponse"),
    idempotencyKey: varchar("idempotencyKey", { length: 128 }).notNull().unique(),
    timestamp: timestamp("timestamp").defaultNow().notNull(),
  },
  (t) => ({ sessionIdx: index("ea_session_idx").on(t.sessionId) }),
);
export type EmergencyAction = typeof emergencyActions.$inferSelect;

// ── Incident timeline ────────────────────────────────────────────
export const incidentTimeline = mysqlTable(
  "incident_timeline",
  {
    id: serial("id").primaryKey(),
    sessionId: bigint("sessionId", { mode: "number", unsigned: true }),
    journeyId: bigint("journeyId", { mode: "number", unsigned: true }),
    event: varchar("event", { length: 128 }).notNull(),
    description: text("description"),
    timestamp: timestamp("timestamp").defaultNow().notNull(),
  },
  (t) => ({ sessionIdx: index("it_session_idx").on(t.sessionId) }),
);
export type IncidentTimelineEntry = typeof incidentTimeline.$inferSelect;

// ── Guardian conversation messages ───────────────────────────────
export const guardianMessages = mysqlTable(
  "guardian_messages",
  {
    id: serial("id").primaryKey(),
    sessionId: bigint("sessionId", { mode: "number", unsigned: true }),
    journeyId: bigint("journeyId", { mode: "number", unsigned: true }),
    userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
    role: mysqlEnum("role", ["guardian", "user", "system"]).notNull(),
    content: text("content").notNull(),
    timestamp: timestamp("timestamp").defaultNow().notNull(),
  },
  (t) => ({ userIdx: index("gm_user_idx").on(t.userId) }),
);
export type GuardianMessage = typeof guardianMessages.$inferSelect;

// ── User safety settings / escalation policy ─────────────────────
export const safetySettings = mysqlTable("safety_settings", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull().unique(),
  escalateToContacts: boolean("escalateToContacts").default(true).notNull(),
  escalateToEmergencyServices: boolean("escalateToEmergencyServices")
    .default(false)
    .notNull(),
  autoCallContacts: boolean("autoCallContacts").default(true).notNull(),
  voiceTriggerPhrase: varchar("voiceTriggerPhrase", { length: 128 })
    .default("safenet i need help")
    .notNull(),
  voiceTriggerEnabled: boolean("voiceTriggerEnabled").default(true).notNull(),
  discreetTriggerEnabled: boolean("discreetTriggerEnabled").default(true).notNull(),
  locationSharingEnabled: boolean("locationSharingEnabled").default(true).notNull(),
  aiVoiceEnabled: boolean("aiVoiceEnabled").default(true).notNull(),
  checkInIntervalSec: int("checkInIntervalSec").default(120).notNull(),
  retentionDays: int("retentionDays").default(30).notNull(),
});
export type SafetySettings = typeof safetySettings.$inferSelect;

// ── Journey monitoring state (check-ins, risk) ───────────────────
export const journeyStates = mysqlTable("journey_states", {
  id: serial("id").primaryKey(),
  journeyId: bigint("journeyId", { mode: "number", unsigned: true })
    .notNull()
    .unique(),
  riskScore: int("riskScore").default(10).notNull(), // 0-100 (100 = safest)
  riskLevel: mysqlEnum("riskLevel", ["LOW", "MEDIUM", "HIGH", "CRITICAL"])
    .default("LOW")
    .notNull(),
  checkInStatus: mysqlEnum("checkInStatus", ["none", "pending", "answered", "missed"])
    .default("none")
    .notNull(),
  checkInSentAt: timestamp("checkInSentAt"),
  lastAnomalyAt: timestamp("lastAnomalyAt"),
  deviationCount: int("deviationCount").default(0).notNull(),
  threatAssessment: json("threatAssessment"),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});
export type JourneyState = typeof journeyStates.$inferSelect;
